#include "RoomRequestHandler.h"

RoomRequestHandler::RoomRequestHandler(LoggedUser user, Room room, RequestHandleFactory& handlerFactory) :m_handlerFactory(handlerFactory), m_user(user), m_room(room), m_roomManager(this->m_handlerFactory.getRoomManager())
{
}

bool RoomRequestHandler::isRequestRelevant(RequestInfo request)
{/*if:
	CloseRoomRequest ?
StartGameRequest ?
GetRoomStateRequest*/
	return false;
}
RequestResult RoomRequestHandler::getRoomState(RequestInfo request)
{
	RoomData room = this->m_room.getRoomData();
	int roomState = this->m_roomManager.getRoomState(room.id);
	//CloseRoomResponse;
	//GetRoomResponse getroom;
	GetRoomStateResponse roomDetails;

	roomDetails.players = m_room.getAllUsers();
	roomDetails.hasGameBegun = room.isActive;
	roomDetails.AnswerCount = room.numOfQuestionsInGame;
	roomDetails.status = roomState;//what this is should be?
	roomDetails.AnswerTimeOut = room.timePerQuestion;
	
	RequestResult r;

	r.response = JsonResponsePacketSerializer::serializeResponse(roomDetails);
	return r;
}
