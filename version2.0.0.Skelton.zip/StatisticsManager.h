#pragma once
#include "IDataBase.h"
#include <vector>
class StatisticsManager
{
public:
	
	StatisticsManager(IDataBase* database);
	std::vector<string> getHighScore();
	std::vector<string> getUserStatistics(string username);

private:
	IDataBase* m_database;
};