import json

"""msgCodes = [
ERROR_RESPONSE = chr(40),
LOGIN_RESPONSE_SUCCESS = chr(41),
SIGNUP_RESPONSE_SUCCESS = chr(42),
LOGIN_REQUEST = chr(71),
SIGN_UP_REQUEST = chr(72),
LOGOUT_REQUEST = chr(73),
LOGIN_REQUEST_FAIL = chr(74),
SIGN_UP_REQUEST_FAIL = chr(75)
]"""
msgCodes = {
    'ERROR_RESPONSE': chr(40),
    'LOGIN_RESPONSE_SUCCESS': chr(41),
    'SIGNUP_RESPONSE_SUCCESS': chr(42),
    'LOGIN_REQUEST': chr(71),
    'SIGNUP_REQUEST': chr(72),
    'LOGOUT_REQUEST': chr(73),
    'LOGIN_REQUEST_FAIL': chr(74),
    'SIGNUP_REQUEST_FAIL': chr(75)
}

def explainServerMsg(msg = "",sever_msg:str = "") -> bool:
    status = '"status":"'

    try:
        msg = ord(msg)
    except Exception:
        pass
    if sever_msg.find(status +str(msg)) == -1:
        return False
    return True
def menu(username=None, password=None, email=None):
    if username != None and password != None:
        if email != None:
            json_data = '{"password":"' + password + '","username":"' + username + '","email":"' + email + '"}'
            return msgCodes['SIGNUP_REQUEST'] + str(len(json_data)).zfill(4) + json_data
        json_data = '{"password":"' + password + '","username":"' + username + '"}'
        return msgCodes['LOGIN_REQUEST'] + str(len(json_data)).zfill(4) + json_data
    inp = input("1. signup\n2. login\n")
    while inp not in ['1', '2']:
        inp = input("invalid input\n")
    if inp == '1':
        email = input("email:\n")
        username = input("username:\n")
        password = input("password:\n")
        json_data = '{"password":"' + password + '","username":"' + username + '","email":"' + email + '"}'
        return msgCodes['SIGNUP_REQUEST'] + str(len(json_data)).zfill(4) + json_data
    if inp == '2':
        username = input("username:\n")
        password = input("password:\n")
        json_data =  '{"password":"' + password + '","username":"' + username + '"}'
        return msgCodes['LOGIN_REQUEST'] +str(len(json_data)).zfill(4) + json_data
def create_json_with_length_prefix():
    username = input("Enter your username: ")
    password = input("Enter your password: ")

    data = {
        "username": username,
        "password": password
    }

    json_data = json.dumps(data)

    # Calculate the length of the JSON string and format it to have a fixed length of 4 characters
    length_prefix = str(len(json_data)).zfill(4)

    # Combine the length prefix and the JSON data
    formatted_json = length_prefix + json_data

    return formatted_json
import socket

SERVER_IP = "127.0.0.1"
SERVER_PORT = 55555


def handleSession():
    # Create a TCP/IP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.settimeout(10)  # Set a timeout of 10 seconds

        # Connecting to the server
        server_address = (SERVER_IP, SERVER_PORT)

        sock.connect(server_address)

        while True:
            server_msg = sock.recv(1024).decode()
            print("Server:", server_msg,end= " -> ")
            if not explainServerMsg("",server_msg):
                print("invalid msg!")
            else:
                for key,value in msgCodes.items():
                    if(explainServerMsg(value,server_msg)):
                        print(key)
                        break
            msg = menu()
            print(msg)
            sock.sendall(msg.encode())
            continue
            """
            enum MessageType : byte
{
enum MessageType
{
	ERROR_RESPONSE = 40,
	LOGIN_RESPONSE_SUCCESS = 41,
	SIGNUP_RESPONSE_SUCCESS = 42,
	LOGIN_REQUEST = 71,
	SIGN_UP_REQUEST = 72,
	LOGOUT_REQUEST = 73,
	LOGIN_REQUEST_FAIL = 74,
	SIGN_UP_REQUEST_FAIL = 75
};"""







            #msg = input("enter\n")
            chr1 = chr(71)
            chr2 = chr(72)
            exampleStr3 = chr1 + """0053{"password":"\\"1' OR '1'='1\\";--","username":"user0"}"""
            exampleStr = chr1 + """0040{"password":"123456","username":"user0"}"""
            exampleStr2 = chr2 + """0068{"password":"123456","username":"user2","email":"1234567@gmail.com"}"""
            example_msgs = [exampleStr, exampleStr2,exampleStr3]

            msg = chr1+ create_json_with_length_prefix()

            if msg == '1' or msg == '0' or msg == '2':
                print("enterrrrrrrrr")
                sock.sendall(example_msgs[int(msg)].encode())
                print(example_msgs[int(msg)])
                continue
            print(msg)
            sock.sendall(msg.encode())
            continue
            # Receive server's message



            # Send message
            #message = input("Enter message to send (type 'exit' to quit): ")
            choice = input("1. signup\n2.login\n")
            if choice == 1:
                #message = ""
                #message = chr1
                user = input("enter username\n")
                password = input("enter password\n")
                email =input("enter email\n")
                headers = """{"password":"""
                headers += '"'+password +'","username":"'+user+'","email":'+'email"}'
                str:msgLen = ""
                if len(headers) < 1000:
                    if len(headers) <100:
                        if len(headers) <10:
                            msgLen = "000"+len(headers)
                        msgLen = "00" +len(headers)
                    msgLen = "000" +len(headers)
                message +=msgLen +headers


            if len(message) > 2**32:
                continue
            if message.lower() == 'exit':
                break
            try:
                message = example_msgs[int(message)]
                print(message)
            except Exception:
                pass
            message = "{:04d}".format(len(message)) + message
            sock.sendall(message.encode())

    except socket.timeout:
        print("Connection timed out.")
    except ConnectionRefusedError:
        print("Connection refused. Make sure the server is running.")
    except Exception as e:
        print("Error:", e)
    finally:
        # Close the socket
        sock.close()


if __name__ == "__main__":
    handleSession()
