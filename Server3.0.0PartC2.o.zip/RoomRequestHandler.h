#pragma once

#include "IRequestHandler.h"
#include "RequestHandleFactory.h"
class RequestHandleFactory;
class RoomRequestHandler :public IRequestHandler
{
public:
	RoomRequestHandler(LoggedUser user, Room room, RequestHandleFactory& handlerFactory);
	bool isRequestRelevant(RequestInfo request) override;
	RequestResult getRoomState(RequestInfo request);
protected:
	Room m_room;
	LoggedUser m_user;
	RoomManager& m_roomManager;
	RequestHandleFactory& m_handlerFactory;

};