#pragma once
#include <string>
class LoggedUser
{
public:
	LoggedUser(std::string username);
	std::string getUserName();
private:
	std::string _userName;
};