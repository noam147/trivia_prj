﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class signUpPage : Form
    {
        public signUpPage()
        {
            InitializeComponent();
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            MainScreen frm = new  MainScreen();
            //Form1 frm = new Form1();
            frm.Show();
            this.Close();
            //frm.ShowDialog();
        }

        private void signUpSenderButton_Click(object sender, EventArgs e)
        {
            //send request to server 
            this.warningLabel.Text = "user name already exsist.";//for example
        }
    }
}
