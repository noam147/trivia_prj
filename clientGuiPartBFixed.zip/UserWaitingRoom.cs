﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class UserWaitingRoom : Form
    {
        private string username;
        public UserWaitingRoom(string user,string roomName)
        {
            int numQuestions = 0;
            float timePerQuestion = 0;//get this from server
            InitializeComponent();
            this.userNameLabel.Text = user;
            this.roomNameLabel.Text = "you are connected to room: " + roomName;
            this.label5.Text = "current users are: ";
            this.label4.Text = "number of questions: "+numQuestions+", time per question: "+timePerQuestion;
            this.username = user;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loggedUserPage frm = new loggedUserPage(this.username);
            frm.Show();
            this.Close();
        }
    }
}
