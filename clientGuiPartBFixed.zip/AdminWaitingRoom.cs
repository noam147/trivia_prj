﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace clientGuiTrivia
{
    public partial class AdminWaitingRoom : Form
    {
        private string username;

        public AdminWaitingRoom(string user,int maxPlayers, int numQuestions, float timePerQuestion,string roomName)
        {
            username = user;
            InitializeComponent();
            this.label7.Text = "max players: " + maxPlayers + ", number of questions: " + numQuestions + ", time for each question: " + timePerQuestion;
            this.label6.Text = "you are connected to room: " + roomName;
            this.usernameLabel.Text = username;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //send msg to server aboout closeing the room
            loggedUserPage frm = new loggedUserPage(username);
            frm.Show();
            this.Close();
        }
    }
}
