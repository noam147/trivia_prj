﻿using JsonSerialzierHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class loggedUserPage : Form
    {
        private string username;
        private ClientHandler clientHandler;
        private bool _sendLogOutRequest = false;
        public loggedUserPage(string user, ClientHandler clientHandler)
        {
            InitializeComponent();
            this.username = user;
            this.clientHandler = clientHandler;
            this.label1.Text += user;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this._sendLogOutRequest = true;
            //send to server log out request
             logoutMessageFields logoutMessageFields_ = new logoutMessageFields();
            logoutMessageFields_.username = username;
           clientHandler.sendMsg( Serializer.serialize(logoutMessageFields_));
            clientHandler.receiveMsg();
            this.Invoke((MethodInvoker)delegate {
                MainScreen frm = new MainScreen(clientHandler);
                frm.FormClosed += (formClosedSender, formClosedEventArgs) => {
                    // This code will execute when the loggedUserPage form is closed
                    this.Hide(); // Close the current form after the loggedUserPage form is closed
                    this.Close();
                };
                this.Hide();
                this.Close();
                frm.ShowDialog();
            });

        }

        private void button6_Click(object sender, EventArgs e)
        {
            bestScorePage frm = new bestScorePage(this.username,clientHandler);
            frm.Show();
            this._sendLogOutRequest = false;
            this.Close();
            
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CreateRoomPage frm = new CreateRoomPage(this.username, clientHandler);
            frm.Show();
            this._sendLogOutRequest = false;
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            UserStatusPage frm = new UserStatusPage(this.username, clientHandler);
            frm.Show();
            this._sendLogOutRequest = false;
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            JoinRoomPage frm = new JoinRoomPage(this.username, clientHandler);
            frm.Show();
            this._sendLogOutRequest = false;
            this.Close();
        }

        private void loggedUserPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this._sendLogOutRequest)
            {
                logoutMessageFields logoutMessageFields = new logoutMessageFields();
                logoutMessageFields.username = username;

                string msg = Serializer.serialize(logoutMessageFields);
                this.clientHandler.sendMsg(msg);
                this.clientHandler.receiveMsg();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this._sendLogOutRequest = false;
            this.Close();
            AddNewQuestions frm = new AddNewQuestions(this.username, clientHandler);
            frm.Show();

        }
    }
}
