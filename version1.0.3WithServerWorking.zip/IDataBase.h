#pragma once
#include "sqlite3.h"
#include <string>
#define DB_NAME "data.db"
#include <iostream>
using std::cout;
using std::string;
using std::endl;
class IDataBase
{
public:
	virtual bool open() = 0;
	virtual bool close() = 0;
	virtual int doesUserxsist(std::string username) = 0;
	virtual int doesPasswordMach(std::string username,std::string password) = 0;
	virtual int addNewUser(std::string username, std::string password,std::string email) = 0;
};