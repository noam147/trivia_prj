﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class AdminWaitingRoom : Form
    {
        private string username;

        public AdminWaitingRoom(string user,int maxPlayers, int numQuestions, float timePerQuestion,string roomName)
        {
            username = user;
            InitializeComponent(roomName,user,maxPlayers,numQuestions,timePerQuestion);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //send msg to server aboout closeing the room
            loggedUserPage frm = new loggedUserPage(username);
            frm.Show();
            this.Close();
        }
    }
}
