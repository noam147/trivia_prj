#include "RoomRequestHandler.h"

RoomRequestHandler::RoomRequestHandler(LoggedUser user, Room room, RequestHandleFactory& handlerFactory) :m_handlerFactory(handlerFactory), m_user(user), m_room(room), m_roomManager(this->m_handlerFactory.getRoomManager())
{
}

bool RoomRequestHandler::isRequestRelevant(RequestInfo request)
{/*if:
	CloseRoomRequest ?
StartGameRequest ?
GetRoomStateRequest*/
	return false;
}


RequestResult RoomRequestHandler::closeRoom(RequestInfo request)
{
	return RequestResult();
}

RequestResult RoomRequestHandler::startGame(RequestInfo request)
{
	return RequestResult();
}

RequestResult RoomRequestHandler::getRoomState(RequestInfo request)
{
	RoomData room = this->m_room.getRoomData();
	int roomState = this->m_roomManager.getRoomState(room.id);
	return RequestResult();
}
