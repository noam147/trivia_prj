
#pragma once
#include <sstream>
#include <iomanip>
#include <string>
#include "RoomManager.h"
#include "json.hpp"
#include "RequestError.hpp"
#include "userDetalis.h"
#include "CommunicationHelper.h"

using json = nlohmann::json;

struct ErrorResponse {
	std::string message;
};
struct LoginResponse {
	int status;
};
struct SignupResponse {
	int status;
};
typedef struct{
	int status;
} LogoutResponse;

typedef struct {
	int status;
} JoinRoomResponse;

typedef struct {
	int status;
} CreateRoomResponse;

typedef struct {
	std::vector<RoomData> roomList;
} GetRoomResponse;

typedef struct {
	std::vector<std::string> userNames;
} GetPlayersInRoomResponse;

typedef struct {
	std::vector<std::string> playerStatistics;
}GetPlayerStatisticsResponse;

typedef struct {
	std::vector<userDetails> users;
} GetHighScoreResponse;

class JsonResponsePacketSerializer//msgs from the server to client
{
public:
	static std::string serializeResponse(ErrorResponse error); //: Buffer
	static  std::string serializeResponse(LoginResponse log); //: Buffer
	static  std::string serializeResponse(SignupResponse sign); //: Buffer
	static  std::string serializeResponse(LogoutResponse sign); //: Buffer
	static  std::string serializeResponse(JoinRoomResponse sign); //: Buffer
	static  std::string serializeResponse(CreateRoomResponse sign); //: Buffer
	static  std::string serializeResponse(GetRoomResponse sign); //: Buffer
	static  std::string serializeResponse(GetPlayersInRoomResponse sign); //: Buffer
	static  std::string serializeResponse(GetHighScoreResponse sign); //: Buffer
	static  std::string serializeResponse(GetPlayerStatisticsResponse sign); //: Buffer



	static std::string addLengthToMsg(std::string msg);//function will take regular msg and insert zeros to gete the protocol correctly, example: input: msg = "hello" output: "0005hello"
private:
	
};

