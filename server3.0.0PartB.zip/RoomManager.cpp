#include "RoomManager.h"

void RoomManager::createRoom(LoggedUser user, RoomData roomdata)
{
    Room r(roomdata);
    this->m_rooms.insert(std::make_pair(this->_roomId,r));
    this->_roomId++;
}

void RoomManager::deleteRoom(int ID)
{
    for (auto it = this->m_rooms.begin(); it != this->m_rooms.end(); it++)
    {
        if (it->first == ID)
        {
            m_rooms.erase(it);
            return;
        }
    }
}

int RoomManager::getRoomState(int ID)
{
    return this->getRoom(ID).getRoomData().isActive;
}

std::vector<RoomData> RoomManager::getRooms()
{
    std::vector<RoomData> rooms;
    for (auto it = this->m_rooms.begin(); it != this->m_rooms.end(); it++)
    {
        rooms.push_back(it->second.getRoomData());
    }
    return rooms;
}

Room& RoomManager::getRoom(int ID)
{
    for (auto it = this->m_rooms.begin(); it != this->m_rooms.end(); it++)
    {
        if (it->first == ID)
        {
            return it->second;
        }
    }

}


