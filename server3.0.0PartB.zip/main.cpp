#pragma comment (lib, "ws2_32.lib")
#include "Communicator.h"
#include "WSAInitializer.h"
#include <iostream>
#include "IDataBase.h"
#include "SqliteDataBase.h"

#include "RoomAdminRequestHandler.h"
//#include "RoomMemberRequestHandler.h"
string s(int m);
void s2(string data);
int main() {
	s(30);
	s2(s(128));
	LoggedUser u("a");
	RoomData roomdata;
	Room r(roomdata);
	RequestHandleFactory f;
	//RoomAdminRequestHandler c(u, r, f);
	Server s;
	s.run();
	return 0;
}
string s(int m)
{
	//input - 127 output: 000127inaski
	//input 128 - ouput : 0010
	//intput 129 - output: 0011
	string str = "0000";
	str[3] = (char)(m % 127);
	m /= 127;
	str[2] = (char)(m % 127);
	m /= 127;
	str[1] = m % 127;
	m /= 127;
	str[0] = m % 127;
	return str;
}
void s2(string data)
{
	int len = data[3] + data[2] * 127 + data[1] * 127 * 127 + data[0] * 127 * 127 * 127;
}