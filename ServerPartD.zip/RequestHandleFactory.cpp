#include "RequestHandleFactory.h"

RequestHandleFactory::RequestHandleFactory():m_StatisticsManager(m_database)
{
	this->m_database = new SqliteDataBase();
	m_database->open();
	m_StatisticsManager.setDataBase(m_database);
}

LoginRequestHandler* RequestHandleFactory::createLoginRequestHandler()
{
	LoginRequestHandler* l = new LoginRequestHandler(*this);
	return l;
}

LoginManager& RequestHandleFactory::getLoginManager()
{
	return this->m_loginManager;
}

MenuRequestHandler* RequestHandleFactory::createMenuRequestHandler(LoggedUser user)
{
	MenuRequestHandler* m = new MenuRequestHandler(*this,user);
	return m;
}

StatisticsManager& RequestHandleFactory::getStatisticsManager()
{
	return this->m_StatisticsManager;
}

RoomManager& RequestHandleFactory::getRoomManager()
{
	return this->m_roomManager;
}
