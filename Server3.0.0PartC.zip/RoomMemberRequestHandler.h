#pragma once
/*
#include "RoomRequestHandler.h"
class RoomMemberRequestHandler : public RoomRequestHandler
{
public:
	RoomMemberRequestHandler(LoggedUser user, Room room, RequestHandleFactory& handlerFactory) :RoomRequestHandler(user, room, handlerFactory)
	{

	}
	RequestResult handleRequest(RequestInfo request) override;
	RequestResult closeRoom(RequestInfo request);
	RequestResult startGame(RequestInfo request);
};*/