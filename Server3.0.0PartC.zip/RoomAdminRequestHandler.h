#pragma once
#include "RoomRequestHandler.h"
/*
class RoomAdminRequestHandler :public RoomRequestHandler
{
	RoomAdminRequestHandler(LoggedUser user, Room room, RequestHandleFactory& handlerFactory) :RoomRequestHandler(user, room, handlerFactory)
	{
	}
	RequestResult handleRequest(RequestInfo request) override;
};*/