#include "SqliteDataBase.h"



bool SqliteDataBase::open()
{
	bool flag = false;
	std::ifstream file(DB_NAME);
	if (file.is_open() && file.peek() != std::ifstream::traits_type::eof())//if file is good
	{
		file.close();
	}
	else
	{
		flag = true;
		file.close();
		//std::cout << "file is not exsist or empty - continue\n";
		
		
	}
	int res = sqlite3_open(DB_NAME, &_db);
	if (res != SQLITE_OK)
	{
		cout << "ho no\n";
	}
	if (flag)
	{
		createTables();
	}
	
	return res;
}

bool SqliteDataBase::close()
{
	sqlite3_close(_db);
	return false;
}

int SqliteDataBase::doesUserxsist(std::string username)
{
	printTables();
	string curr = username;
	string str = "select * from USERS;";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, SqliteDataBase::helpFindUser, &username, &errMessage);
		if (strcmp(curr.c_str(), username.c_str()) != 0)
		{
			return MACH;
		}
	}
	catch (...)
	{

	}
	return 0;
}

int SqliteDataBase::doesPasswordMach(std::string username, std::string password)
{
	
	std::string curr = password;
	string str = "select * from USERS where password = " +password+ "; ";
	cout << str<<"\n";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement,SqliteDataBase::helpFindPassword, &password, &errMessage);
		if (strcmp(curr.c_str(), password.c_str()) != 0)
		{
			return MACH;
		}
	}
	catch (...)
	{

	}
	return 0;
}

int SqliteDataBase::addNewUser(std::string username, std::string password, std::string email)
{

	string str = "INSERT INTO USERS (username,password,email) VALUES ('" + username + "', '" + password + "', '" + email + "'); ";
	const char* sqlStatement = str.c_str();
	cout << sqlStatement << "\n";
	bool flag = execSqlCommand(sqlStatement, _db);
	return flag;
}

bool SqliteDataBase::createTables()
{

	const char* sqlStatement = "create table USERS (username TEXT NOT NULL,password TEXT NOT NULL,email TEXT NOT NULL);";
	bool flag = execSqlCommand(sqlStatement, _db);
	return flag;
}

void SqliteDataBase::printTables()
{
	string str = "select * from USERS;";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, SqliteDataBase::helpPrint, nullptr, &errMessage);
	}
	catch (...)
	{

	}
	cout << "finish print\n";
}

bool SqliteDataBase::execSqlCommand(const char* sqlStatement, sqlite3* db)
{
	char* errMessage = nullptr;
	int res = sqlite3_exec(db, sqlStatement, nullptr, nullptr, &errMessage);
	if (res != SQLITE_OK)
	{
		if (errMessage)
		{
			std::cout << errMessage << "\n";
		}
	
		return false;
	}
	return true;
}

int SqliteDataBase::helpFindPassword(void* data, int argc, char** argv, char** azColName)
{
	string* password = static_cast<string*>(data);

	for (int i = 0; i < argc;i++)//should be only one username with name not multiple
	{
		if (strcmp(azColName[i], "password") == 0)
		{
			if (strcmp(argv[i], password->c_str()) == 0)
			{
				*password = ":)";
				return MACH;
			}
		}
		
	}
	return 0;
}

int SqliteDataBase::helpFindUser(void* data, int argc, char** argv, char** azColName)
{
	string* username = static_cast<string*>(data);
	for (int i = 0; i < argc; i++) {
		//cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << "\n";
		if (strcmp(azColName[i], "username") == 0)
		{
			if (argv[i] == *username)
			{
				*username = ":)";
				return MACH;
			}
		}
	}
	return 0;
}

int SqliteDataBase::helpPrint(void* data, int argc, char** argv, char** azColName)
{
	for (int i = 0; i < argc; i++) {
		cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << "\n";
	}
	
	return 0;
}
