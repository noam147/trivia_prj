#pragma once


#pragma once
#include "IRequestHandler.h"
#include "RequestHandleFactory.h"
class RequestHandleFactory;
class MenuRequestHandler : public IRequestHandler
{
public:
	bool isRequestRelevant(RequestInfo info) override;//func check if msg is sign in or login type of msg
	RequestResult handleRequest(RequestInfo info) override;
private:
};

