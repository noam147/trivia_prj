#pragma once

#include "IRequestHandler.h"
#include "SqliteDataBase.h"
#include "LoginRequestHandler.h"
#include "LoginManager.h"
class LoginRequestHandler;
class LoginManager;
class RequestHandleFactory
{
public:
	LoginRequestHandler* createLoginRequestHandler();
	LoginManager& getLoginManager();

private:
	LoginManager m_loginManager;
	IDataBase* m_database;
};

