#include "RoomRequestHandler.h"
#include "RequestHandleFactory.h"
RoomRequestHandler::~RoomRequestHandler()
{
	this->m_handlerFactory.getLoginManager().logOut(this->m_user.getUserName());

	//this->m_room.removeUser(m_user); cause error
}
RoomRequestHandler::RoomRequestHandler(LoggedUser user, Room& room, RequestHandleFactory& handlerFactory) : m_user(user), m_room(room), m_roomManager(handlerFactory.getRoomManager()), m_handlerFactory(handlerFactory)
{
	
}

bool RoomRequestHandler::isRequestRelevant(RequestInfo request)
{
	char codeMsg = request.buffer[0];
	if (codeMsg == CLOSE_ROOM_REQUEST || codeMsg == START_GAME_REQUEST || codeMsg == GET_ROOM_STATE_REQUEST)
		return true;
	/*if:
	CloseRoomRequest ?
StartGameRequest ?
GetRoomStateRequest*/
	return false;
}

RequestResult RoomRequestHandler::handleRequest(RequestInfo info)
{
	return RequestResult();
}
RequestResult RoomRequestHandler::getRoomState(RequestInfo request)
{
	//for member:
	//check if admin closed room:
	if (!this->m_roomManager.isRoomExsist(this->m_room.getRoomData().id))//if room closed
	{
		RequestResult r;
		r.newHandler = m_handlerFactory.createMenuRequestHandler(this->m_user);
		r.response = JsonResponsePacketSerializer::serializeResponse(LEAVE_ROOM_RESPONSE_SUCCESS);
		this->m_user.setRoomId(-1);
		return r;
	}
	//check if admin start room: (can not delete this becaue we have to get a new handler)
	if (this->m_room.getRoomData().isActive == true)
	{
		RequestResult r;
		//r.newHandler = m_handlerFactory. // create game handler
		r.response = JsonResponsePacketSerializer::serializeResponse(START_GAME_RESPONSE_SUCCESS);
		return r;

	}



	RoomData room = this->m_room.getRoomData();
	int roomState = this->m_roomManager.getRoomState(room.id);
	//CloseRoomResponse;
	//GetRoomResponse getroom;
	GetRoomStateResponse roomDetails;

	roomDetails.players = m_room.getAllUsers();
	roomDetails.hasGameBegun = room.isActive;//if game started
	roomDetails.AnswerCount = room.numOfQuestionsInGame;
	roomDetails.status = roomState;//what this is should be?
	roomDetails.AnswerTimeOut = room.timePerQuestion;
	
	RequestResult r;

	r.response = JsonResponsePacketSerializer::serializeResponse(roomDetails);
	r.newHandler = nullptr;
	return r;
}

