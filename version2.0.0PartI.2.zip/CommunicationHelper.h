#pragma once

#include <vector>
#include <string>
#include <WinSock2.h>
#include "JsonResponsePacketSerializer.h"

enum MessageType : byte
{
	ERROR_RESPONSE = 40,
	LOGIN_RESPONSE_SUCCESS = 41,
	SIGNUP_RESPONSE_SUCCESS = 42,
	LOGOUT_RESPONSE_SUCCESS = 43,
	GET_ROOM_RESPONSE_SUCCESS = 45,
	GET_PLAYER_IN_ROOM_RESPONSE_SUCCESS = 46,
	JOIN_ROOM_RESPONSE_SUCCESS = 47,
	CREATE_ROOM_RESPONSE_SUCCESS = 48,
	GET_HIGH_SCORE_RESPONSE_SUCCESS = 49,
	GET_PERSONAL_STAT_RESPONSE_SUCCESS = 50,
	CLOSE_ROOM_RESPONSE_SUCCESS = 51,
	START_GAME_RESPONSE_SUCCESS = 52,
	GET_ROOM_STATE_RESPONSE_SUCCESS = 53,
	LEAVE_ROOM_RESPONSE_SUCCESS = 54,
	GET_GAME_RESULT_RESPONSE_SUCCESS = 55,
	SUBMIT_ANSWER_RESPONSE_SUCCESS = 56,
	GET_QUESTION_RESPONSE_SUCCESS = 57,
	LEAVE_GAME_RESPONSE_SUCCESS = 58
};
//should we seperate enums for more specific categories?
/*enum clientLoginMsg : byte
{
	LOGIN_REQUEST = 71,
	SIGN_UP_REQUEST = 72,
	LOGOUT_REQUEST = 73
};
enum clientMenuMsg : byte
{
	JOIN_ROOM_REQUEST = 76,
	GET_ROOM_REQUEST = 45,
	GET_PLAYER_IN_ROOM_REQUEST = 46,
	CREATE_ROOM_REQUEST = 48,
	GET_HIGH_SCORE_REQUEST = 49,
	GET_PERSONAL_STAT_REQUEST = 50,
	CLOSE_ROOM_REQUEST = 51,
	START_GAME_REQUEST = 52,
	GET_ROOM_STATE_REQUEST = 53,
	LEAVE_ROOM_REQUEST = 54,
	GET_GAME_RESULT_REQUEST = 55,
	SUBMIT_ANSWER_REQUEST = 56,
	GET_QUESTION_REQUEST = 57,
	LEAVE_GAME_REQUEST = 58
};*/
enum clientMessageType : byte
{
	LOGIN_REQUEST = 71,
	SIGN_UP_REQUEST = 72,
	LOGOUT_REQUEST = 73,
	LOGIN_REQUEST_FAIL = 74,
	SIGN_UP_REQUEST_FAIL = 75,
	JOIN_ROOM_REQUEST = 76,
	GET_ROOM_REQUEST = 45,
	GET_PLAYER_IN_ROOM_REQUEST = 46,
	CREATE_ROOM_REQUEST = 48,
	GET_HIGH_SCORE_REQUEST = 49,
	GET_PERSONAL_STAT_REQUEST = 50,
	CLOSE_ROOM_REQUEST = 51,
	START_GAME_REQUEST = 52,
	GET_ROOM_STATE_REQUEST = 53,
	LEAVE_ROOM_REQUEST = 54,
	GET_GAME_RESULT_REQUEST = 55,
	SUBMIT_ANSWER_REQUEST = 56,
	GET_QUESTION_REQUEST = 57,
	LEAVE_GAME_REQUEST = 58
};

class CommunicationHelper
{
public:
	static int getMessageTypeCode(const SOCKET sc);
	static void sendHello(SOCKET sc);
	static int getIntPartFromSocket(const SOCKET sc, const int bytesNum);
	static int getLengthPartFromSocket(const SOCKET sc, const int bytesNum,char& codeMsg);
	static std::string getPartFromSocket(const SOCKET sc, const int bytesNum);
	static void sendData(const SOCKET sc, const std::string message);
	static std::string getPaddedNumber(const int num, const int digits);
	static char* stringToCharArr(std::string str);
	static char* createErrorResponse();


private:
	static std::string getPartFromSocket(const SOCKET sc, const int bytesNum, const int flags);

};

