﻿/*
 this file contains the definitions of the messages structure 
 and the message codes for the serialized messages
(the ones sent from the client to the server)
 */


namespace JsonSerialzierHelper
{
    public enum SerializeMessageCode
    {
        LOGIN_CODE = 1,
        SIGNUP_CODE,
        LOGOUT_CODE,
        LOGIN_FAILED,
        SIGNUP_FAILED,
        JOIN_ROOM_CODE,
        GET_ROOM_CODE,
        GET_PLAYER_IN_ROOM_CODE,
        CREATE_ROOM_CODE,
        GET_HIGH_SCORE_CODE,
        GET_PERSONAL_STAT_CODE,
        //CLOSE_ROOM_CODE,
        //START_GAME_CODE,
        //GET_ROOM_STATE_CODE,
       // LEAVE_ROOM_CODE,
        //GET_GAME_RESULT_CODE,
        //SUBMIT_ANSWER_CODE,
        //GET_QUESTION_CODE,
        //LEAVE_GAME_CODE
    }

    // login related structs
    public struct loginMessageFields {
        public string username;
        public string password;
    }

    public struct signupMessageFields
    {
        public string username;
        public string password;
        public string email;
    }

    // menue related structs
    public struct getPlayersInRoomMessageFields
    {
        public int roomId;
    }

    public struct getRoomsMessageFields
    {
        // no data needed
    }

    public struct joinRoomMessageFields
    {
        public int roomId;
    }

    public struct CreateRoomMessageFields
    {
        public  string roomName;
        public int maxUsers;
        public int questionCount;
        public int questionTimeout;
    }

    public struct getStatsMessageFields
    {
        // no data needed
        public string username;
    }

    public struct getHighScoreMessageFields
    {
        // no data needed
    }

    public struct logoutMessageFields
    {
        public string username;
        // no data needed
    }
}
