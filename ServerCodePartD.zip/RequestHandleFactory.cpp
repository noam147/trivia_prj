#include "RequestHandleFactory.h"
#include "RoomMemberRequestHandler.h"
#include "RoomAdminRequestHandler.h"
RequestHandleFactory::RequestHandleFactory():m_StatisticsManager(m_database)
{
	this->m_database = new SqliteDataBase();
	m_database->open();
	m_StatisticsManager.setDataBase(m_database);
}

LoginRequestHandler* RequestHandleFactory::createLoginRequestHandler()
{
	LoginRequestHandler* l = new LoginRequestHandler(*this);
	return l;
}

LoginManager& RequestHandleFactory::getLoginManager()
{
	return this->m_loginManager;
}

MenuRequestHandler* RequestHandleFactory::createMenuRequestHandler(LoggedUser user)
{
	MenuRequestHandler* m = new MenuRequestHandler(*this,user);
	return m;
}

StatisticsManager& RequestHandleFactory::getStatisticsManager()
{
	return this->m_StatisticsManager;
}

RoomManager& RequestHandleFactory::getRoomManager()
{
	return this->m_roomManager;
}

IRequestHandler* RequestHandleFactory::createRoomAdminRequestHandler(LoggedUser user, Room room)
{
	RoomRequestHandler* roomAdmin = new RoomAdminRequestHandler(user,room,*this);
	IRequestHandler* i = roomAdmin;
	return i;
}

RoomRequestHandler* RequestHandleFactory::createRoomMemberRequestHandler(LoggedUser user, Room room)
{
	try
	{
		RoomRequestHandler* roomAdmin = new RoomMemberRequestHandler(user, room, *this);
		return roomAdmin;
	}
	catch (...)
	{
		return new RoomRequestHandler(user,room,*this);
	}
	
}
