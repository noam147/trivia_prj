#include "RoomRequestHandler.h"
#include "RequestHandleFactory.h"
RoomRequestHandler::~RoomRequestHandler()
{
	this->m_handlerFactory.getLoginManager().logOut(this->m_user.getUserName());
}
RoomRequestHandler::RoomRequestHandler(LoggedUser user, Room room, RequestHandleFactory& handlerFactory) :m_handlerFactory(handlerFactory), m_user(user), m_room(room), m_roomManager(this->m_handlerFactory.getRoomManager())
{
}

bool RoomRequestHandler::isRequestRelevant(RequestInfo request)
{
	char codeMsg = request.buffer[0];
	if (codeMsg == CLOSE_ROOM_REQUEST || codeMsg == START_GAME_REQUEST || codeMsg == GET_ROOM_STATE_REQUEST)
		return true;
	/*if:
	CloseRoomRequest ?
StartGameRequest ?
GetRoomStateRequest*/
	return false;
}
RequestResult RoomRequestHandler::handleRequest(RequestInfo info)
{
	return RequestResult();
}
RequestResult RoomRequestHandler::getRoomState(RequestInfo request)
{
	RoomData room = this->m_room.getRoomData();
	int roomState = this->m_roomManager.getRoomState(room.id);
	//CloseRoomResponse;
	//GetRoomResponse getroom;
	GetRoomStateResponse roomDetails;

	roomDetails.players = m_room.getAllUsers();
	roomDetails.hasGameBegun = room.isActive;
	roomDetails.AnswerCount = room.numOfQuestionsInGame;
	roomDetails.status = roomState;//what this is should be?
	roomDetails.AnswerTimeOut = room.timePerQuestion;
	
	RequestResult r;

	r.response = JsonResponsePacketSerializer::serializeResponse(roomDetails);
	r.newHandler = nullptr;
	return r;
}
