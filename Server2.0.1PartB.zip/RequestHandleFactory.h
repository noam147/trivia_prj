#pragma once

#include "IRequestHandler.h"
#include "SqliteDataBase.h"
#include "LoginRequestHandler.h"
#include "LoginManager.h"
#include "StatisticsManager.h"

#include "MenuRequestHandler.h"
class MenuRequestHandler;
class LoginRequestHandler;
class LoginManager; 
class RequestHandleFactory
{
public:
	RequestHandleFactory();
	LoginRequestHandler* createLoginRequestHandler();
	LoginManager& getLoginManager();
	MenuRequestHandler* createMenuRequestHandler(LoggedUser user);
	StatisticsManager& getStatisticsManager();
	RoomManager& getRoomManager();

private:
	LoginManager m_loginManager;
	IDataBase* m_database = new SqliteDataBase();
	RoomManager m_roomManager;
	StatisticsManager m_StatisticsManager;

};

