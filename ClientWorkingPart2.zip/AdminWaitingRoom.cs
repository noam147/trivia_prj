﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class AdminWaitingRoom : Form
    {
        private string username;
        private ClientHandler clientHandler;

        private CancellationTokenSource cts = new CancellationTokenSource(); // Used for cancelling task
        private static readonly object lockSocket = new object();
        private Task task = null;

        public AdminWaitingRoom(string user, int maxPlayers, int numQuestions, float timePerQuestion, string roomName, ClientHandler clientHandler)
        {
            username = user;
            InitializeComponent();
            this.label7.Text = "max players: " + maxPlayers + ", number of questions: " + numQuestions + ", time for each question: " + timePerQuestion;
            this.label6.Text = "you are connected to room: " + roomName;
            this.clientHandler = clientHandler;
            this.task = Task.Run(() => RefreshUsers(cts.Token));

        }

        private async Task RefreshUsers(CancellationToken token)
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    char codeMsg = (char)JsonSerialzierHelper.SerializeMessageCode.GET_PLAYER_IN_ROOM_CODE;
                    string msgToSend = "{}";
                    Serializer.addLength(ref msgToSend);
                    msgToSend = codeMsg + msgToSend;
                    string msgReceived = "";

                    lock (lockSocket)
                    {
                        clientHandler.sendMsg(msgToSend);
                        msgReceived = clientHandler.receiveMsg();
                    }

                    var usersList = Deserializer.desirializeGetPlayersResponse(msgReceived);
                    string userNames = "";
                    if (usersList != null)
                    {
                        foreach (var user in usersList)
                        {
                            userNames += user + "\n";
                        }
                    }
                    if (string.IsNullOrEmpty(userNames))
                    {
                        userNames = "No Players In Room";
                    }

                    // Update the UI on the UI thread
                    this.Invoke((MethodInvoker)(() => this.UsersList.Text = userNames));

                    await Task.Delay(1000, token);
                }
            }
            catch (TaskCanceledException)
            {
                Console.WriteLine("Task was canceled.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            char codeMsg = (char)JsonSerialzierHelper.SerializeMessageCode.GET_ADMIN_CLOSE_ROOM_REQUEST;
            string msgToSend = "{}";
            Serializer.addLength(ref msgToSend);
            msgToSend = codeMsg + msgToSend;
            string msgReceived = "";

            lock (lockSocket)
            {
                clientHandler.sendMsg(msgToSend);
                msgReceived = clientHandler.receiveMsg();
            }

            if (Deserializer.desirializeServerAnswerToAdminStartGameRequest(msgReceived))
            {
                var frm = new loggedUserPage(username, clientHandler);
                frm.Show();
                this.Close();
            }
            else
            {
                var frm2 = new loggedUserPage(username, clientHandler);
                frm2.Show();
                this.Close();
            }
        }

        private void startGmaeButton_Click(object sender, EventArgs e)
        {
            char codeMsg = (char)JsonSerialzierHelper.SerializeMessageCode.GET_ADMIN_START_GAME_REQUEST;
            string msgToSend = "{}";
            Serializer.addLength(ref msgToSend);
            msgToSend = codeMsg + msgToSend;
            string msgReceived = "";

            lock (lockSocket)
            {
                clientHandler.sendMsg(msgToSend);
                msgReceived = clientHandler.receiveMsg();
            }

            if (Deserializer.desirializeServerAnswerToAdminStartGameRequest(msgReceived))
            {
                // get into game
            }
            else
            {
                // display error msg
            }

            var frm = new loggedUserPage(username, clientHandler);
            frm.Show();
            this.Close();
        }

        private void AdminWaitingRoom_FormClosing(object sender, FormClosingEventArgs e)
        {
            cts.Cancel();
        }


        private void AdminWaitingRoom_Load(object sender, EventArgs e)
        {
        }

        private void UsersList_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}