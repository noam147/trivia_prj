#pragma once
#include "IDataBase.h"
#include <cmath>
#include <vector>
class StatisticsManager
{
public:
	
	StatisticsManager(IDataBase* database);
	std::vector<string> getHighScore();
	std::vector<string> getUserStatistics(string username);

private:
	IDataBase* m_database;
};