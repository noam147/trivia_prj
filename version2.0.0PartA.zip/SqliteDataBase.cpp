#include "SqliteDataBase.h"



bool SqliteDataBase::open()
{
	bool flag = false;
	std::ifstream file(DB_NAME);
	if (file.is_open() && file.peek() != std::ifstream::traits_type::eof())//if file is good
	{
		file.close();
	}
	else
	{
		flag = true;
		file.close();
		//std::cout << "file is not exsist or empty - continue\n";
		
		
	}
	int res = sqlite3_open(DB_NAME, &_db);
	if (res != SQLITE_OK)
	{
		cout << "ho no\n";
	}
	if (flag)
	{
		createTables();
	}
	
	return res;
}

bool SqliteDataBase::close()
{
	sqlite3_close(_db);
	return false;
}

int SqliteDataBase::doesUserxsist(std::string username)
{
	printTables();
	string curr = username;
	string str = "select * from USERS;";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, SqliteDataBase::helpFindUser, &username, &errMessage);
		if (strcmp(curr.c_str(), username.c_str()) != 0)
		{
			return MACH;
		}
	}
	catch (...)
	{

	}
	return 0;
}

int SqliteDataBase::doesPasswordMach(std::string username, std::string password)
{
	//printTables();
	std::string curr = password;
	string str = "select * from USERS where password = '" +password+ "'; ";
	cout << str<<"\n";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement,SqliteDataBase::helpFindPassword, &password, &errMessage);
		if (strcmp(curr.c_str(), password.c_str()) != 0)
		{
			return MACH;
		}
	}
	catch (...)
	{

	}
	return 0;
}

int SqliteDataBase::addNewUser(std::string username, std::string password, std::string email)
{

	string str = "INSERT INTO USERS (username,password,email) VALUES ('" + username + "', '" + password + "', '" + email + "'); ";
	const char* sqlStatement = str.c_str();
	cout << sqlStatement << "\n";
	bool flag = execSqlCommand(sqlStatement, _db);
	return flag;
}

bool SqliteDataBase::createTables()
{
	bool flag = true;
	flag = this->createUsersTable();
	flag = this->createStatisticsTable()&&flag;
	return flag;
}

void SqliteDataBase::printTables()
{
	string str = "select * from USERS;";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, SqliteDataBase::helpPrint, nullptr, &errMessage);
	}
	catch (...)
	{

	}
	cout << "finish print\n";
}

std::vector<Question> SqliteDataBase::getQuestions(int numQuestions)
{
	return std::vector<Question>();
}

float SqliteDataBase::getPlayerAverageAnswerTime(std::string playerName)
{
	std::string curr = playerName;
	float avg = -1;
	string str = "select * from statistics where username = '" + playerName + "'; ";
	cout << str << "\n";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, SqliteDataBase::getPlayerAverageAnswerTime, &avg, &errMessage);
		if (avg != -1)
		{
			return avg;
		}
	}
	catch (...)
	{

	}
	return FAIL;
}

int SqliteDataBase::getNumOfCorrectAnswers(std::string playerName)
{
	int numCorrectAnswers = -1;
	string str = "select * from statistics where username = '" + playerName + "'; ";
	cout << str << "\n";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, SqliteDataBase::getNumOfCorrectAnswers, &numCorrectAnswers, &errMessage);
		if (numCorrectAnswers != -1)
		{
			return numCorrectAnswers;
		}
	}
	catch (...)
	{

	}
	return FAIL;
}

int SqliteDataBase::getNumOfTotalAnswers(std::string playerName)
{
	int numAnswers = -1;
	string str = "select * from statistics where username = '" + playerName + "'; ";
	cout << str << "\n";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, SqliteDataBase::getNumOfTotalAnswers, &numAnswers, &errMessage);
		if (numAnswers != -1)
		{
			return numAnswers;
		}
	}
	catch (...)
	{

	}
	return FAIL;
}

int SqliteDataBase::getNumOfPlayerGames(std::string playerName)
{
	int playerGames = -1;
	string str = "select * from statistics where username = '" + playerName + "'; ";
	cout << str << "\n";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, SqliteDataBase::getNumOfPlayerGames, &playerGames, &errMessage);
		if (playerGames != -1)
		{
			return playerGames;
		}
	}
	catch (...)
	{

	}
	return FAIL;
}

int SqliteDataBase::getPlayerScore(std::string playerName)
{
	int score = -1;
	string str = "select * from statistics where username = '" + playerName + "'; ";
	cout << str << "\n";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, SqliteDataBase::getPlayerScore, &score, &errMessage);
		if (score != -1)
		{
			return score;
		}
	}
	catch (...)
	{

	}
	return FAIL;
}

std::vector<std::string> SqliteDataBase::getHighScores()
{
	return std::vector<std::string>();
}

bool SqliteDataBase::createUsersTable()
{
	const char* sqlStatement = "create table USERS (username TEXT NOT NULL,password TEXT NOT NULL,email TEXT NOT NULL);";
	bool flag = execSqlCommand(sqlStatement, _db);
	return flag;
}

bool SqliteDataBase::createStatisticsTable()
{
	const char* sqlStatement = "create table statistics (\
	username TEXT NOT NULL,\
	numberOfGames INTEGER,\
	numberOfAnswers INTEGER,\
	numberOfRightAnswers INTEGER,\
	avgTimeForAnswer REAL\
score INTEGER);";//real is float
	bool flag = execSqlCommand(sqlStatement, _db);
	return flag;
}

bool SqliteDataBase::execSqlCommand(const char* sqlStatement, sqlite3* db)
{
	char* errMessage = nullptr;
	int res = sqlite3_exec(db, sqlStatement, nullptr, nullptr, &errMessage);
	if (res != SQLITE_OK)
	{
		if (errMessage)
		{
			std::cout << errMessage << "\n";
		}
	
		return false;
	}
	return true;
}

int SqliteDataBase::helpFindPassword(void* data, int argc, char** argv, char** azColName)
{
	string* password = static_cast<string*>(data);

	for (int i = 0; i < argc;i++)//should be only one username with name not multiple
	{
		if (strcmp(azColName[i], "password") == 0)
		{
			if (strcmp(argv[i], password->c_str()) == 0)
			{
				*password = ":)";
				return MACH;
			}
		}
		
	}
	return 0;
}

int SqliteDataBase::helpFindUser(void* data, int argc, char** argv, char** azColName)
{
	string* username = static_cast<string*>(data);
	for (int i = 0; i < argc; i++) {
		//cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << "\n";
		if (strcmp(azColName[i], "username") == 0)
		{
			if (argv[i] == *username)
			{
				*username = ":)";
				return MACH;
			}
		}
	}
	return 0;
}

int SqliteDataBase::helpPrint(void* data, int argc, char** argv, char** azColName)
{
	for (int i = 0; i < argc; i++) {
		cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << "\n";
	}
	
	return 0;
}

int SqliteDataBase::getPlayerAverageAnswerTime(void* data, int argc, char** argv, char** azColName)
{
	float* avg = static_cast<float*>(data);
	for (int i = 0; i < argc; i++) {
		//cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << "\n";
		if (strcmp(azColName[i], "avgTimeForAnswer") == 0)
		{
			if (argv[i] == std::to_string(*avg))
			{
				*avg = atoi(argv[i]);
				return MACH;
			}
		}
	}
	return 0;
}

int SqliteDataBase::getNumOfCorrectAnswers(void* data, int argc, char** argv, char** azColName)
{
	int* num = static_cast<int*>(data);
	for (int i = 0; i < argc; i++) {
		//cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << "\n";
		if (strcmp(azColName[i], "numberOfRightAnswers") == 0)
		{
			if (argv[i] == std::to_string(*num))
			{
				*num = atoi(argv[i]);
				return MACH;
			}
		}
	}
	return 0;
}

int SqliteDataBase::getNumOfTotalAnswers(void* data, int argc, char** argv, char** azColName)
{
	int* num = static_cast<int*>(data);
	for (int i = 0; i < argc; i++) {
		//cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << "\n";
		if (strcmp(azColName[i], "numberOfAnswers") == 0)
		{
			if (argv[i] == std::to_string(*num))
			{
				*num = atoi(argv[i]);
				return MACH;
			}
		}
	}
	return 0;
}

int SqliteDataBase::getNumOfPlayerGames(void* data, int argc, char** argv, char** azColName)
{
	int* num = static_cast<int*>(data);
	for (int i = 0; i < argc; i++) {
		//cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << "\n";
		if (strcmp(azColName[i], "numberOfGames") == 0)
		{
			if (argv[i] == std::to_string(*num))
			{
				*num = atoi(argv[i]);
				return MACH;
			}
		}
	}
	return 0;
}

int SqliteDataBase::getPlayerScore(void* data, int argc, char** argv, char** azColName)
{
	int* num = static_cast<int*>(data);
	for (int i = 0; i < argc; i++) {
		//cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << "\n";
		if (strcmp(azColName[i], "score") == 0)
		{
			if (argv[i] == std::to_string(*num))
			{
				*num = atoi(argv[i]);
				return MACH;
			}
		}
	}
	return 0;
}

/*
int SqliteDataBase::helpGetPlayerInfo(string playername, string functoActivate)
{
	std::string curr = playername;
	float avg = -1;
	string str = "select * from statistics where username = '" + playername + "'; ";
	cout << str << "\n";
	char* errMessage = nullptr;
	const char* sqlStatement = str.c_str();
	try
	{
		int res = sqlite3_exec(_db, sqlStatement, functoActivate, &avg, &errMessage);
		if (avg != -1)
		{
			return avg;
		}
	}
	catch (...)
	{

	}
	return FAIL;
}*/
