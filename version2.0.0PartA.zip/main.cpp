#pragma comment (lib, "ws2_32.lib")
#include "Communicator.h"
#include "WSAInitializer.h"
#include <iostream>
#include "IDataBase.h"
#include "SqliteDataBase.h"
int main() {
	Server s;
	s.run();
	return 0;
}