#pragma once
#include "IDataBase.h"
#include <fstream>
#define MACH 5//result of sucsess
#define FAIL -5

class SqliteDataBase:public IDataBase//maybe put mutex when i accsses the file - id the _db opening the file after it opened at the first time?
{
public:

	bool open() override;
	bool close() override;
	int doesUserxsist(std::string username) override;
	int doesPasswordMach(std::string username, std::string password) override;
	int addNewUser(std::string username, std::string password, std::string email) override;
	bool createTables();
	void printTables();

	std::vector<Question> getQuestions(int numQuestions) override;
	float getPlayerAverageAnswerTime(std::string playerName) override;
	int getNumOfCorrectAnswers(std::string playerName) override;
	int getNumOfTotalAnswers(std::string playerName) override;
	int getNumOfPlayerGames(std::string playerName) override;
	int getPlayerScore(std::string playerName) override;
	std::vector<std::string> getHighScores() override;
private:
	bool createUsersTable();
	bool createStatisticsTable();
	static bool execSqlCommand(const char* sqlStatement, sqlite3* db);
	static int helpFindPassword(void* data, int argc, char** argv, char** azColName);
	static int helpFindUser(void* data, int argc, char** argv, char** azColName);
	static int helpPrint(void* data, int argc, char** argv, char** azColName);

	static int getPlayerAverageAnswerTime(void* data, int argc, char** argv, char** azColName);
	static int getNumOfCorrectAnswers(void* data, int argc, char** argv, char** azColName);
	static int getNumOfTotalAnswers(void* data, int argc, char** argv, char** azColName);
	static int getNumOfPlayerGames(void* data, int argc, char** argv, char** azColName);
	static int getPlayerScore(void* data, int argc, char** argv, char** azColName);
	int helpGetPlayerInfo(string playername,string functoActivate);
	sqlite3* _db;
};