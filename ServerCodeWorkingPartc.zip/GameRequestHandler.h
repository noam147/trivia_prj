#pragma once
#include "GameManager.h"
#include "RequestHandleFactory.h"
class GameRequestHandler : public IRequestHandler
{
public:
	GameRequestHandler(RequestHandleFactory& handlerFacroty, Game& game, LoggedUser user);
	~GameRequestHandler();
	bool isRequestRelevant(RequestInfo) override;
	RequestResult handleRequest(RequestInfo) override;
		

private:
	Game& m_game;
	LoggedUser m_user;//current user that in room- in active game
	GameManager & m_gameManager;
	RequestHandleFactory& m_handlerFacroty;

	RequestResult getQuestion(RequestInfo info);
	RequestResult submitAnswer(RequestInfo info);
	RequestResult getGameResults(RequestInfo info);
	RequestResult leaveGame(RequestInfo info);

};