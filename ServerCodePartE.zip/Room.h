#pragma once
#include "LoggedUser.h"
#include <vector>
struct RoomData
{
	unsigned int id;
	std::string name;
	int maxPlayers;
	int numOfQuestionsInGame;
	int timePerQuestion;
	int isActive;
};
class Room
{

public:
	Room(RoomData roomdata);
	void addUser(LoggedUser user);
	void  removeUser(LoggedUser user);
	std::vector<std::string> getAllUsers();
	RoomData getRoomData();//add this, func wasn't in uml
private:
	RoomData m_metadata;
	std::vector<LoggedUser> m_users;
	//std::string _owner; maybe need to add?

};
