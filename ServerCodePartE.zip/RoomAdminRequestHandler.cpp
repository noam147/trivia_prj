#include "RoomAdminRequestHandler.h"
#include "RequestHandleFactory.h"
/*
RequestResult RoomAdminRequestHandler::handleRequest(RequestInfo request)
{
    return RequestResult();
}*/

RequestResult RoomAdminRequestHandler::handleRequest(RequestInfo info)
{
	char a = info.buffer[0];
	switch (a) {
	case GET_ROOM_STATE_REQUEST:
		return this->getRoomState(info);
		break;
	case START_GAME_REQUEST:
		return this->startGame(info);
		break;
	case CLOSE_ROOM_REQUEST:
		return this->closeRoom(info);
		break;
	default:
		throw RequestError();
	}
    return RequestResult();
}

bool RoomAdminRequestHandler::isRequestRelevant(RequestInfo request)
{

	char codeMsg = request.buffer[0];
	if (codeMsg == CLOSE_ROOM_REQUEST || codeMsg == START_GAME_REQUEST || codeMsg == GET_ROOM_STATE_REQUEST)
		return true;
	return false;
}

RequestResult RoomAdminRequestHandler::startGame(RequestInfo request)
{
	RequestResult r;
	r.newHandler = nullptr;//replace to game handler
	r.response = JsonResponsePacketSerializer::serializeResponse();
	//send to eveyone - game started
	
	return r;
}

RequestResult RoomAdminRequestHandler::closeRoom(RequestInfo request)
{
	//send to eveyone - room destroyed
	std::vector<std::string> players = this->m_room.getAllUsers();
	this->m_roomManager.deleteRoom(this->m_room.getRoomData().id);
	return RequestResult();
}

