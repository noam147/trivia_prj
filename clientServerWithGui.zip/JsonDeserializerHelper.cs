﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace JsonDeserialzierHelper
{
    static class JsonDeserializerHelper
    {
        public enum DeserializeMessageCode
        {
            ERROR_CODE = 40,
            LOGIN_CODE,
            SIGNUP_CODE,
            LOGOUT_CODE,
            JOIN_ROOM_CODE,
            GET_ROOM_CODE,
            GET_PLAYER_IN_ROOM_CODE,
            CREATE_ROOM_CODE,
            GET_HIGH_SCORE_CODE,
            GET_PERSONAL_STAT_CODE,
            //CLOSE_ROOM_CODE,
            //START_GAME_CODE,
            //GET_ROOM_STATE_CODE,
            // LEAVE_ROOM_CODE,
            //GET_GAME_RESULT_CODE,
            //SUBMIT_ANSWER_CODE,
            //GET_QUESTION_CODE,
            //LEAVE_GAME_CODE
        }

        public struct RoomData {
             public List<string> Rooms { get; set; }
        }
        public struct PersonData
        {
            public List<string> Users { get; set; }
        }
        public struct HighscoreData
        {
            public List<string> HighScores { get; set; }
        }
        public struct StatData
        {
            public List<string> UserStatistics { get; set; }
        }

    }
}
