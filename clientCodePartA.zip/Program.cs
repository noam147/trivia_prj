﻿using Newtonsoft.Json;
using System.Net.Sockets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace ConsoleApp1Check
{


    internal class Program
    {
        public struct Account
        {
            public string name;
            public string email;
        }
        static void Main(string[] args)
        {
            ClientHandler clientHandler;
            clientHandler = new ClientHandler();
            if(!clientHandler.connectServer())
            {
                Console.WriteLine("error during find server!");
                Console.ReadLine();
                return;
            }
            Console.WriteLine((clientHandler.receiveMsg()));
            
            //example of json useages:
            Account account = new Account
            {
                name = "nameee",
                email = "myEmail"
            };
            string json = JsonConvert.SerializeObject(account, Formatting.Indented);
            Console.WriteLine(json);
            string json2 = @"{
  ""name"": ""name2"",
  ""email"": ""myEmail.2""
}";
            Account account2 = JsonConvert.DeserializeObject<Account>(json2);
            Console.WriteLine(account2.name);
            Console.WriteLine(account2.email);
            Console.ReadLine();
        }
    }

}
