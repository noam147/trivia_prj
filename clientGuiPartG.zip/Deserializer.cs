﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JsonDeserialzierHelper;
using Newtonsoft.Json;
//using static ConsoleApp1Check.Program;
using static JsonDeserialzierHelper.JsonDeserializerHelper;

namespace clientGuiTrivia
{
    static class Deserializer
    {
        public static bool desirializeLoginResponse(string loginResponse)
        {
            if (loginResponse[0] != (char)DeserializeMessageCode.LOGIN_CODE)
            {  
                return false;
            }
            return true;
        }

        public static bool desirializeSignupResponse(string signupResponse)
        {
            if (signupResponse[0] != (char)DeserializeMessageCode.SIGNUP_CODE)
            {
                return false;
            }
            return true;
        }

        public static bool desirializeLogoutResponse(string logoutResponse)
        {
            if (logoutResponse[0] != (char)DeserializeMessageCode.LOGOUT_CODE)
            {
                return false;
            }
            return true;
        }

        public static bool desirializeJoinRoomResponse(string joinRoomResponse)
        {
            if (joinRoomResponse[0] != (char)DeserializeMessageCode.JOIN_ROOM_CODE)
            {
                return false;
            }
            return true;
        }

        public static bool desirializeCreateRoomResponse(string createRoomResponse)
        {
            if (createRoomResponse[0] != (char)DeserializeMessageCode.CREATE_ROOM_CODE)
            {
                return false;
            }
            return true;
        }

        //if the return value is null, it means the message returned was either error or invalid
        public static List<string> desirializeGetRoomsResponse(string getRoomsResponse)
        {
            if (getRoomsResponse[0] != (char)DeserializeMessageCode.GET_ROOM_CODE)
            {
                return null;
            }

            getRoomsResponse = getRoomsResponse.Substring(5);
            RoomData roomList = JsonConvert.DeserializeObject<RoomData>(getRoomsResponse);
            return roomList.Rooms;
        }

        //if the return value is null, it means the message returned was either error or invalid
        public static List<string> desirializeGetPlayersResponse(string getPlayersResponse)
        {
            if (getPlayersResponse[0] != (char)DeserializeMessageCode.GET_PLAYER_IN_ROOM_CODE)
            {
                return null;
            }

            getPlayersResponse = getPlayersResponse.Substring(5);
            PersonData PlayersList = JsonConvert.DeserializeObject<PersonData>(getPlayersResponse);
            return PlayersList.Users;
        }

        //if the return value is null, it means the message returned was either error or invalid
        public static List<string> desirializeGetStatsResponse(string getStatsResponse)
        {
            if (getStatsResponse[0] != (char)DeserializeMessageCode.GET_PERSONAL_STAT_CODE)
            {
                return null;
            }

            getStatsResponse = getStatsResponse.Substring(5);
            StatData statsList = JsonConvert.DeserializeObject<StatData>(getStatsResponse);
            return statsList.UserStatistics;
            return null;
        }

        //if the return value is null, it means the message returned was either error or invalid
        public static List<Dictionary<string, string>> desirializeGetHighscoreResponse(string getHighscoreResponse)
        {
            if (getHighscoreResponse[0] != (char)DeserializeMessageCode.GET_HIGH_SCORE_CODE)
            {
                return null;
            }

            getHighscoreResponse = getHighscoreResponse.Substring(5);
            //HighscoreData highscore = JsonConvert.DeserializeObject<HighscoreData>(getHighscoreResponse);
            HighscoreData highscore = JsonConvert.DeserializeObject<HighscoreData>(getHighscoreResponse);
            return highscore.HighScores;
            
        }
    }
}
