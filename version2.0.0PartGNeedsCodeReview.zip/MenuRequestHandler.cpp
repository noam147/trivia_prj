#include "MenuRequestHandler.h"

MenuRequestHandler::MenuRequestHandler(RequestHandleFactory& handlerFactory, LoggedUser user) :m_handlerFactory(handlerFactory),m_user(user)
{
}

bool MenuRequestHandler::isRequestRelevant(RequestInfo info)
{
    return false;
}

RequestResult MenuRequestHandler::handleRequest(RequestInfo info)
{
    return RequestResult();
}
