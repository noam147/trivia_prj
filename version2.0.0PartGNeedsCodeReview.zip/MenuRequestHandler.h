#pragma once


#pragma once
#include "IRequestHandler.h"
#include "RequestHandleFactory.h"
class RequestHandleFactory;
class MenuRequestHandler : public IRequestHandler
{
public:
	MenuRequestHandler(RequestHandleFactory& handlerFactory,LoggedUser user);
	bool isRequestRelevant(RequestInfo info) override;//func check if msg is sign in or login type of msg
	RequestResult handleRequest(RequestInfo info) override;
private:
	LoggedUser m_user;
	RequestHandleFactory& m_handlerFactory;

};

