#include "GameManager.h"

Game GameManager::createGame(Room room)
{
	Game g();
	return Game();
	//m_games.push_back(g);
	//return g;
}

void GameManager::deleteGame(int gameId)
{
	for (auto it = this->m_games.begin(); it != this->m_games.end(); it++)
	{
		//it->
	}
}
