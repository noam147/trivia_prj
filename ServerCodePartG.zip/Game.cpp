#include "Game.h"

void Game::removePlayer(LoggedUser user)
{
	for (auto it = this->m_players.begin(); it != this->m_players.end(); it++)
	{
		LoggedUser curr = it->first;
		if (user.getUserName() == curr.getUserName())
		{
			this->m_players.erase(it);
		}
	}
}
