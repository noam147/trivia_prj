#pragma once
#include "GameManager.h"
#include "RequestHandleFactory.h"
class GameRequestHandler : public IRequestHandler
{
public:
	GameRequestHandler(RequestHandleFactory& handlerFacroty, Game& game, LoggedUser user);
	bool isRequestRelevant(RequestInfo) override;
	RequestResult handleRequest(RequestInfo) override;
		

private:
	Game& m_game;
	LoggedUser m_user;
	GameManager & m_gameManager;
	RequestHandleFactory& m_handlerFacroty;

	RequestResult getQuestion(RequestInfo);
	RequestResult submitAnswer(RequestInfo);
	RequestResult getGameResults(RequestInfo);
	RequestResult leaveGame(RequestInfo);

};