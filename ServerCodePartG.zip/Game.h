#pragma once
#include "Question.h"
#include <map>
#include "LoggedUser.h"
struct GameData
{
	Question currentQuestion;
	unsigned int correctAnswerCount;
	unsigned int wrongAnswerCount;
	unsigned int averangeAnswerTime;
};
class Game
{
public:
	//TO DO
	Question getQuestionForUser(LoggedUser user);
	void submitAnswer();
	void removePlayer(LoggedUser user);
private:
	void submitGameStatsToDB(GameData gamedata);

	std::vector<Question> m_questions;
	std::map<LoggedUser, GameData> m_players;
	int m_gameId;

};