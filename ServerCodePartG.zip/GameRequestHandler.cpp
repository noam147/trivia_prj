#include "GameRequestHandler.h"



GameRequestHandler::GameRequestHandler(RequestHandleFactory& handlerFacroty, Game& game, LoggedUser user):m_handlerFacroty(handlerFacroty),m_game(game),m_gameManager(handlerFacroty.getGameManager()),m_user(user)
{
}

bool GameRequestHandler::isRequestRelevant(RequestInfo)
{
    return false;
}

RequestResult GameRequestHandler::handleRequest(RequestInfo)
{
    return RequestResult();
}
