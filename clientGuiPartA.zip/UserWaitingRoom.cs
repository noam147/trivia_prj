﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class UserWaitingRoom : Form
    {
        public UserWaitingRoom(string user,string roomName)
        {
            int numQuestions = 0;
            float timePerQuestion = 0;//get this from server
            InitializeComponent();
        }
    }
}
