﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class CreateRoomPage : Form
    {
        private string username;
        public CreateRoomPage(string username)
        {
            this.username = username;
            InitializeComponent();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            loggedUserPage frm = new loggedUserPage(this.username);
            this.Close();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string roomName = this._roomName.Text;
            int numPlayers = 0;
            int numQuestions = 0;
            float time = 0;
            try
            {
                numPlayers = int.Parse(this._NumberOfPlayers.Text);
                numQuestions =int.Parse(this._NumberOfQuestions.Text);
                time = float.Parse(this._TimeForQuestion.Text);
            }
            catch
            {
                this.warningLabel.Text = "error inputs are invalid!";
                return;
            }



            AdminWaitingRoom frm = new AdminWaitingRoom(this.username,numPlayers,numQuestions,time,roomName);
            this.Close();
            frm.Show();
            //send to server room request
            //... will be continued later

        }
    }
}
