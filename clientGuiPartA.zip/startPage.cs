﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class MainScreen : Form
    {
        Timer timer = new Timer();
        private string _username = "";
       
        public MainScreen()
        {
            InitializeComponent();
            button1.MouseEnter += button_MouseHover;
            button1.MouseLeave += button_MouseLeave;

            signUpButton.MouseEnter += new System.EventHandler(this.button_MouseHover);
            button3.MouseEnter += new System.EventHandler(this.button_MouseHover);
            button4.MouseEnter += new System.EventHandler(this.button_MouseHover);
            button5.MouseEnter += new System.EventHandler(this.button_MouseHover);
            button6.MouseEnter += new System.EventHandler(this.button_MouseHover);
            button1.MouseEnter += new System.EventHandler(this.button_MouseLeave);
            signUpButton.MouseEnter += new System.EventHandler(this.button_MouseLeave);
            button3.MouseEnter += new System.EventHandler(this.button_MouseLeave);
            button4.MouseEnter += new System.EventHandler(this.button_MouseLeave);
            button5.MouseEnter += new System.EventHandler(this.button_MouseLeave);
            button6.MouseEnter += new System.EventHandler(this.button_MouseLeave);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _username = this.textBox1.Text;
            string password = this.textBox2.Text;
            //send to server login request
            //get server response
            //if server respone == status 1:
            loggedUserPage frm = new loggedUserPage(this._username);
            this.Hide();
            frm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //go to sign up page
            //send msg to server
            //wariningLabel.Text = "passwword or user name are incorrect"; //for exasmple
            signUpPage frm = new signUpPage();
           
            //frm.Show();
            this.Hide();
            frm.ShowDialog();

        }

   


        private void button_MouseEnter(object sender, EventArgs e)
        {
 
            Button button = (Button)sender;
            button.BackColor = Color.Black;
            button.ForeColor = Color.Black;
            button.Size = new System.Drawing.Size(button.Size.Width+5,button.Size.Height+5);
        }

        private void button_MouseLeave(object sender, EventArgs e)
        {
            Button button = (Button)sender;
                button.BackColor = SystemColors.Control;
                button.ForeColor = SystemColors.ControlText;
              //  button.Size = new System.Drawing.Size(button.Size.Width - 5, button.Size.Height - 5);
            
        }

        private void button_MouseHover(object sender, EventArgs e)
        {
            //this.textBox1.Text = this.GetType().ToString(); used for debug
            Button button = (Button)sender;
            button.BackColor = Color.Black;
            button.ForeColor = Color.Black;
            //button.Size = new System.Drawing.Size(button.Size.Width + 5, button.Size.Height + 5);

        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }





    }
}
