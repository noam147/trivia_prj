﻿namespace clientGuiTrivia
{
    partial class CreateRoomPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this._roomName = new System.Windows.Forms.TextBox();
            this._NumberOfPlayers = new System.Windows.Forms.TextBox();
            this._TimeForQuestion = new System.Windows.Forms.TextBox();
            this._NumberOfQuestions = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.warningLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(109, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "room name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(109, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "number of players";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(109, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "number of questions";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(109, 239);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "time for question";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(247, 295);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 69);
            this.button1.TabIndex = 4;
            this.button1.Text = "send";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(613, 46);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 85);
            this.button2.TabIndex = 5;
            this.button2.Text = "back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // _roomName
            // 
            this._roomName.Location = new System.Drawing.Point(308, 74);
            this._roomName.Name = "_roomName";
            this._roomName.Size = new System.Drawing.Size(100, 26);
            this._roomName.TabIndex = 6;
            // 
            // _NumberOfPlayers
            // 
            this._NumberOfPlayers.Location = new System.Drawing.Point(308, 124);
            this._NumberOfPlayers.Name = "_NumberOfPlayers";
            this._NumberOfPlayers.Size = new System.Drawing.Size(100, 26);
            this._NumberOfPlayers.TabIndex = 7;
            // 
            // _TimeForQuestion
            // 
            this._TimeForQuestion.Location = new System.Drawing.Point(308, 233);
            this._TimeForQuestion.Name = "_TimeForQuestion";
            this._TimeForQuestion.Size = new System.Drawing.Size(100, 26);
            this._TimeForQuestion.TabIndex = 8;
            // 
            // _NumberOfQuestions
            // 
            this._NumberOfQuestions.Location = new System.Drawing.Point(308, 180);
            this._NumberOfQuestions.Name = "_NumberOfQuestions";
            this._NumberOfQuestions.Size = new System.Drawing.Size(100, 26);
            this._NumberOfQuestions.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 10;
            // 
            // warningLabel
            // 
            this.warningLabel.AutoSize = true;
            this.warningLabel.Location = new System.Drawing.Point(152, 13);
            this.warningLabel.Name = "warningLabel";
            this.warningLabel.Size = new System.Drawing.Size(0, 20);
            this.warningLabel.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = this.username + " ";
            // 
            // CreateRoomPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.warningLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this._NumberOfQuestions);
            this.Controls.Add(this._TimeForQuestion);
            this.Controls.Add(this._NumberOfPlayers);
            this.Controls.Add(this._roomName);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CreateRoomPage";
            this.Text = "CreateRoomPage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox _roomName;
        private System.Windows.Forms.TextBox _NumberOfPlayers;
        private System.Windows.Forms.TextBox _TimeForQuestion;
        private System.Windows.Forms.TextBox _NumberOfQuestions;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label warningLabel;
        private System.Windows.Forms.Label label6;
    }
}