﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class JoinRoomPage : Form
    {
        private string username;
        private string currRoomName = "";
        public JoinRoomPage(string user)
        {
            this.username = user;
            
            InitializeComponent();
            this.joinButton.Enabled = false; //in the start the button is disabled 
            //send request to server to check avilable rooms
        }

        private void button2_Click(object sender, EventArgs e)
        {
            loggedUserPage frm = new loggedUserPage(this.username);
            this.Close();
            frm.Show();
        }

        private void joinButton_Click(object sender, EventArgs e)
        {
            //send to sesrver request
            UserWaitingRoom frm = new UserWaitingRoom(this.username,currRoomName);
            this.Close();
            frm.Show();

        }
    }
}
