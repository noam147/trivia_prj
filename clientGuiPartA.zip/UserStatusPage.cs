﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class UserStatusPage : Form
    {
        private string username;
        public UserStatusPage(string user)
        {
            this.username = user;
            InitializeComponent();
            //send the server request
            int numberGames = 0;
            int numberRightAnswer = 0;
            int numberWrong = 0;
            float avgTime = 0;
            label2.Text += numberGames;
            label3.Text += numberRightAnswer;
            label4.Text += numberWrong;
            label5.Text += avgTime;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loggedUserPage frm = new loggedUserPage(this.username);
            frm.Show();
            this.Close();
        }
    }
}
