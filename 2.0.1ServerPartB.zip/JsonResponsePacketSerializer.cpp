
#include "JsonResponsePacketSerializer.h"
#include <iostream>
#include <string>
#define _CRT_SECURE_NO_WARNINGS

char* JsonResponsePacketSerializer::serializeResponse(ErrorResponse error)
{
    std::string msg = "{\"message\":\""+error.message+"\"}";
    //json j = json::parse(R"({"message":"ERROR"})");
    json j = json::parse(msg);
    std::string jsonString = j.dump();//json to string
    std::string updateMsg = addLengthToMsg(jsonString);//add length to msg
    char codeMsg = ERROR_RESPONSE;
    updateMsg = codeMsg + updateMsg;//add codemsg

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());//copy
    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(LoginResponse log)
{

    std::string msg = "{\"status\":\"" + std::to_string(log.status) + "\"}";
    json j = json::parse(msg);

    std::string jsonString = j.dump();
    std::string updateMsg = addLengthToMsg(jsonString);
    char codeMsg = log.status;
    updateMsg = codeMsg + updateMsg;//add codemsg

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());

    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(SignupResponse sign)
{
    std::string msg = "{\"status\":\"" + std::to_string(sign.status) + "\"}";
    json j = json::parse(msg);
    std::string jsonString = j.dump();
    std::string updateMsg = addLengthToMsg(jsonString);
    char codeMsg = sign.status;
    updateMsg = codeMsg + updateMsg;//add code

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    return bytes;
}
char* JsonResponsePacketSerializer::serializeResponse(LogoutResponse sign)
{
    std::string msg = "{\"status\":\"" + std::to_string(sign.status) + "\"}";
    json j = json::parse(msg);
    std::string jsonString = j.dump();
    std::string updateMsg = addLengthToMsg(jsonString);
    char codeMsg = sign.status;
    updateMsg = codeMsg + updateMsg;//add code

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(JoinRoomResponse sign)
{
    std::string msg = "{\"status\":\"" + std::to_string(sign.status) + "\"}";
    json j = json::parse(msg);
    std::string jsonString = j.dump();
    std::string updateMsg = addLengthToMsg(jsonString);
    char codeMsg = JOIN_ROOM_RESPONSE_SUCCESS;
    updateMsg = codeMsg + updateMsg;//add code

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(CreateRoomResponse sign)
{
    std::string msg = "{\"status\":\"" + std::to_string(sign.status) + "\"}";
    json j = json::parse(msg);
    std::string jsonString = j.dump();
    std::string updateMsg = addLengthToMsg(jsonString);
    char codeMsg = CREATE_ROOM_RESPONSE_SUCCESS;
    updateMsg = codeMsg + updateMsg;//add code

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(GetRoomResponse sign)
{
    std::string roomNames = "\"Rooms\": [";
    for (auto room : sign.roomList)
        roomNames += "\"" + room.name + "\",";
    if (roomNames.back() == ',')
        roomNames.pop_back();
    roomNames += "]";
    std::string jsonMsg = "{" + roomNames + "}";
    std::string updateMsg = addLengthToMsg(jsonMsg);
    char codeMsg = GET_ROOM_RESPONSE_SUCCESS;
    updateMsg = codeMsg + updateMsg;//add code

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(GetPlayersInRoomResponse sign)
{
    std::string userNames = "\"Users\": [";
    for (auto name : sign.userNames)
        userNames += "\"" + name + "\", ";
    if (userNames.back() == ',')
        userNames.pop_back();
    userNames += "]";
    std::string jsonMsg = "{" + userNames + "}";
    std::string updateMsg = addLengthToMsg(jsonMsg);
    char codeMsg = GET_PLAYER_IN_ROOM_RESPONSE_SUCCESS;
    updateMsg = codeMsg + updateMsg;//add code

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(GetHighScoreResponse sign)
{

    //parse highScores
    std::string HighScores = "\"HighScores\":[";
    for (auto score : sign.highScore)
        HighScores += "\"" + score + "\",";
    if (HighScores.back() == ',')
        HighScores.pop_back();
    HighScores += ']';

    std::string jsonMsg = "{" + HighScores + "}";
    std::string updateMsg = addLengthToMsg(jsonMsg);
    char codeMsg = GET_HIGH_SCORE_RESPONSE_SUCCESS;
    updateMsg = codeMsg + updateMsg;//add code

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(GetPlayerStatisticsResponse sign)
{
    //parse stats
    std::string userStatistic = "\"UserStatistics\": [";
    for (auto stat : sign.playerStatistics)
        userStatistic += "\"" + stat + "\",";
    if (userStatistic.back() == ',')
        userStatistic.pop_back();
    userStatistic += ']';

    std::string jsonMsg = "{" + userStatistic + "}";
    std::string updateMsg = addLengthToMsg(jsonMsg);
    char codeMsg = GET_HIGH_SCORE_RESPONSE_SUCCESS;
    updateMsg = codeMsg + updateMsg;//add code

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    return bytes;
}

std::string JsonResponsePacketSerializer::addLengthToMsg(std::string msg)
{
    unsigned int length = msg.length();
    char msgSize[sizeof(unsigned int) + 1] = { '\0' };
    memcpy(msgSize, &length, sizeof(unsigned int));
    return msgSize + msg;
}

