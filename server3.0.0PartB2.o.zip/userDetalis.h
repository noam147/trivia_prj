#pragma once
#include <string>
struct userDetails
{
	int score;
	std::string user_name;
};