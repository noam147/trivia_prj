﻿using JsonSerialzierHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static JsonDeserialzierHelper.JsonDeserializerHelper;

namespace clientGuiTrivia
{
    public partial class UserWaitingRoom : Form
    {
        private string username;
        private ClientHandler clientHandler;
        private int numPlayers;
        private int numQuestions;

        private CancellationTokenSource cts = new CancellationTokenSource();
        private static readonly object lockSocket = new object();
        private Task task = null;
        public UserWaitingRoom(string user,string roomName, ClientHandler clientHandler)
        {
            numQuestions = 0;
            int numPlayers = 0;
            float timePerQuestion = 0;//get this from server
            InitializeComponent();
            this.userNameLabel.Text = user;
            this.roomNameLabel.Text = "you are connected to room: " + roomName;
            this.usersLabel.Text = "current users are: ";
            this.label4.Text = "number of questions: "+numQuestions+", time per question: "+timePerQuestion;
            this.username = user;
            this.clientHandler = clientHandler;
        }



        private async Task RefreshUsers(CancellationToken token)
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    Console.WriteLine("Task running...");

                    char codeMsg = (char)JsonSerialzierHelper.SerializeMessageCode.GET_ROOM_STATE_CODE;
                    string msgToSend = "{}";
                    Serializer.addLength(ref msgToSend);
                    msgToSend = codeMsg + msgToSend;
                    string msgReceived = "";

                    lock (lockSocket)
                    {
                        clientHandler.sendMsg(msgToSend);
                        msgReceived = clientHandler.receiveMsg();
                    }

                    //this is for user:
                    if (Deserializer.desirializeLeaveRoomResponse(msgReceived))
                    {
                        loggedUserPage loggedUser = new loggedUserPage(username, clientHandler);
                        loggedUser.Show();
                        this.Close();
                        //if the admin exited go to menu?
                    }
                    if (Deserializer.desirializeStartGameResponse(msgReceived))
                    {
                        Game_Questions game = new Game_Questions(username, this.clientHandler, this.numQuestions);
                        //if the admin start game
                        game.Show();
                        this.Close();
                    }
                    var roomData = Deserializer.desirializeGetRoomStateResponse(msgReceived);
                    if (roomData.status == -2)//if error respond
                    {
                        continue;
                    }
                    this.Invoke((MethodInvoker)delegate
                    {
                        string selectedItem = UsersList.SelectedItem?.ToString();

                        UsersList.Items.Clear();
                        foreach (var user in roomData.players)
                        {
                            this.UsersList.Items.Add(user);
                        }

                        if (selectedItem != null && roomData.players.Contains(selectedItem))
                        {
                            UsersList.SelectedItem = selectedItem;
                        }

                        this.UsersList.Refresh();
                    });

                    await Task.Delay(1000, token);
                }
            }
            catch (TaskCanceledException)
            {
                Console.WriteLine("Task was canceled.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error: {ex.Message}");
            }
        }


        public void GetRoomStateFromServer()//thread func
        {
            char length = '\0';
            char codeMsg = (char)JsonSerialzierHelper.SerializeMessageCode.GET_ROOM_STATE_CODE;
            string msgTosend =  "";//send get room code
            msgTosend += codeMsg;
            msgTosend += length + length + length + length;
            this.clientHandler.sendMsg(msgTosend);
            string msgRecived = clientHandler.receiveMsg();
            RoomState roomState = Deserializer.desirializeGetRoomStateResponse(msgRecived);
           
            this.label4.Text = "number of questions: " + roomState.AnswerCount + ", time per question: " + roomState.answerTimeOut;
            if (roomState.hasGameBegun)
            {
                //get into game page
            }
            if(roomState.status == -1)//if admin left
            {
                roomNameLabel.Text = "admin closed Room - you need to exit";
                usersLabel.Text = "";
            }
            if (roomState.status == -2)//if error accuared - server sent invalid msg
            {
                //break;
            }
            if (roomState.players.Count > numPlayers)
            {
                this.usersLabel.Text = "current users are: ";
                for (int i = 0; i < roomState.players.Count; i++)
                {
                    this.usersLabel.Text += roomState.players[i] + ", ";
                }
                this.usersLabel.Text.Substring(0,usersLabel.Text.Length - 2);//crop the last , 
                numPlayers = roomState.players.Count;
            }
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
            char length = '\0';//when leaving - sending to server
            char codeMsg = (char)JsonSerialzierHelper.SerializeMessageCode.GET_LEAVE_ROOM_CODE;
            string msgTosend = "";
            msgTosend += codeMsg;
            msgTosend += length + length + length + length;
            this.clientHandler.sendMsg(msgTosend);
            clientHandler.receiveMsg();
            loggedUserPage frm = new loggedUserPage(this.username,clientHandler);
            frm.Show();
            this.Close();
        }
    }
}
