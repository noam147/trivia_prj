#pragma once
#include "LoggedUser.h"
#include "SqliteDataBase.h"
#include <vector>
class LoginManager
{
public:
	void signUp(std::string username, std::string password, std::string email);
	void logIn(std::string username, std::string password);
	void logUot(std::string username);
private:
	IDataBase* m_dataBase;
	std::vector<LoggedUser> m_loggedUsers;
};