#pragma once
#include "IDataBase.h"
#include <fstream>
#define MACH 5

class SqliteDataBase:public IDataBase
{
public:

	bool open() override;
	bool close() override;
	int doesUserxsist(std::string username) override;
	int doesPasswordMach(std::string username, std::string password) override;
	int addNewUser(std::string username, std::string password, std::string email) override;
	bool createTables();
private:
	static bool execSqlCommand(const char* sqlStatement, sqlite3* db);
	static int helpFindPassword(void* data, int argc, char** argv, char** azColName);
	static int helpFindUser(void* data, int argc, char** argv, char** azColName);
	sqlite3* _db;
};