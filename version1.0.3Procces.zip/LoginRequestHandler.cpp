
#include "LoginRequestHandler.h"

bool LoginRequestHandler::isRequestRelevant(RequestInfo info)
{
	if (info.buffer[0] == LOGIN_REQUEST || info.buffer[0] == SIGN_UP_REQUEST)
	{
		return true;
	}
	return false;
}

RequestResult LoginRequestHandler::handleRequest(RequestInfo info)
{
	RequestResult r;
	r.newHandler;

	if (isRequestRelevant(info))
	{
		if (info.buffer[0] == SIGNUP_RESPONSE)
		{
			
			std::string str = "";
			for (int i = 0; i < info.buffer.size(); i++)
			{
				str += info.buffer[i];
			}
		SignupRequest s = JsonRequestPacketDeserializer::deserializeSignupRequest(CommunicationHelper::stringToCharArr(str));
			r.response;//what thev respone shuld be?
			r.newHandler = new LoginRequestHandler;//next handler is login?
			return r;
		}
		else if (info.buffer[0] == LOGIN_REQUEST)
		{
			std::string str = "";
			for (int i = 0; i < info.buffer.size(); i++)
			{
				str += info.buffer[i];
			}
			LoginRequest s = JsonRequestPacketDeserializer::deserializeLoginRequest(CommunicationHelper::stringToCharArr(str));
			r.response = CommunicationHelper::stringToCharArr("???");//what the respone shuld be?
			r.newHandler;//next handler is ...?
			return r;
		}
		
	}
	return RequestResult();//how to return the next handler?
}

