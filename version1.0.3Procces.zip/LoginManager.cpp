#include "LoginManager.h"

void LoginManager::signUp(std::string username, std::string password, std::string email)
{
	if (m_dataBase->doesUserxsist(username))
	{
		return;//throw error
	}
	else
	{
		this->m_dataBase->addNewUser(username, password, email);
	}
}

void LoginManager::logIn(std::string username, std::string password)
{
	if (m_dataBase->doesUserxsist(username) ==MACH&& m_dataBase->doesPasswordMach(username, password) == MACH)
	{
		m_loggedUsers.push_back(LoggedUser(username));
	}
	else
	{
		//throw error?
	}
}

void LoginManager::logUot(std::string username)
{
	for (auto it = m_loggedUsers.begin(); it != m_loggedUsers.end(); it++)
	{
		if (it->getUserName() == username)
		{
			m_loggedUsers.erase(it);
			return;
		}
	}
	//throw error?
}
