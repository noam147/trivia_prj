#include "JsonRequestPacketDeserializer.h"
#include <iostream>

/*int main()
{
    json j = json::parse(R"({"username":"user1","password":"1234"})");//login request
    std::string msgToSend = "4";//with start code to login
    std::string jsonString = j.dump();
    std::string updateMsg = JsonResponsePacketSerializer::addLengthToMsg(jsonString);
    updateMsg = msgToSend + updateMsg;
    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    LoginRequest e = JsonRequestPacketDeserializer::deserializeLoginRequest(bytes);
    std::cout << e.userName << e.password << "\n";
    ErrorResponse error;
    error.message = "EEEERRRRORRRR";
    JsonResponsePacketSerializer::serializeResponse(error);

    j = json::parse(R"({"username":"user2","password":"0000","email":"something@gmail.com"})");//login request
     msgToSend = "5";//with start code to login
     jsonString = j.dump();
     updateMsg = JsonResponsePacketSerializer::addLengthToMsg(jsonString);
    updateMsg = msgToSend + updateMsg;
     bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    SignupRequest s = JsonRequestPacketDeserializer::deserializeSignupRequest(bytes);
    std::cout << s.userName << s.password <<s.email <<"\n";
    return 0;
}*/

LoginRequest JsonRequestPacketDeserializer::deserializeLoginRequest(const char* buffer)
{
    LoginRequest e;
    try{
    std::string buff(buffer);//get into string format
    buff = buff.substr(1);//remove the first byte - the code msg

    int len = std::stoi(buff.substr(0, 4));//get len of msg - 4 bytes

    std::string jsonMsg = buff.substr(4, len);
    json j = json::parse(jsonMsg);
   
    //should we use try?
        e.userName = j["username"];
        e.password = j["password"];
    }
    catch (...)
    {
       throw RequestError();
    }
    return e;
}

SignupRequest JsonRequestPacketDeserializer::deserializeSignupRequest(const char* Buffer)
{
    SignupRequest s;
    try {
    std::string buff(Buffer);//get into string format
    buff = buff.substr(1);//remove the first byte - the code msg

    int len = std::stoi(buff.substr(0, 4));
    std::string jsonMsg = buff.substr(4, len);
    json j = json::parse(jsonMsg);
        s.userName = j["username"];
        s.password = j["password"];
        s.email = j["email"];
    }
    catch (...)
    {
        throw RequestError();
    }
   
    return s;
}
