#pragma once

#include "IRequestHandler.h"

class RequestHandleFactory
{
public:
	RequestHandleFactory();
};

