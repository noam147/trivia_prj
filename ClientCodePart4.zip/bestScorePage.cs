﻿using JsonDeserialzierHelper;
using JsonSerialzierHelper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace clientGuiTrivia
{
    public partial class bestScorePage : Form
    {
        private string username;
        private ClientHandler clientHandler;
        public bestScorePage(string user, ClientHandler clientHandler)
        {
            this.clientHandler = clientHandler;
            username = user;
            InitializeComponent();
            getHighScoreMessageFields getHighScore = new getHighScoreMessageFields();
            getHighScore.username = username;
            string msgToSend = Serializer.serialize(getHighScore);
            clientHandler.sendMsg(msgToSend);
            string msgRecive = clientHandler.receiveMsg();
            List<Dictionary<string, string>> users = Deserializer.desirializeGetHighscoreResponse(msgRecive);
            Label[] labels = { label1, label2, label3 ,label4,label5};
            for (int i = 0; i < labels.Length; i++)
                labels[i].Text = "";
            for (int i =0; i <users.Count; i++) 
            {
                foreach (var kvp in users[i])
                {
                    labels[i].Text = "The player: "+kvp.Key+" scored: "+kvp.Value;
                    Console.WriteLine($"Key: {kvp.Key}, Value: {kvp.Value}");
                }
                //labels[i].Text = (i+1) + ". The Player: " + users[i].First + "scored: "+users[i].Values;
            }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            loggedUserPage frm = new loggedUserPage(this.username,clientHandler);
            frm.Show();
            this.Close();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void bestScorePage_Load(object sender, EventArgs e)
        {

        }
    }
}
