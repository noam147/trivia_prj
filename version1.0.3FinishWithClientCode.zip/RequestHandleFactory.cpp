#include "RequestHandleFactory.h"

LoginRequestHandler* RequestHandleFactory::createLoginRequestHandler()
{
	LoginRequestHandler* l = new LoginRequestHandler(*this);//to fix
	return l;
}

LoginManager& RequestHandleFactory::getLoginManager()
{
	// TODO: insert return statement here
	return this->m_loginManager;
}
