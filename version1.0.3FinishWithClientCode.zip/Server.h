#pragma once
#include "LoginManager.h"
#include "RequestHandleFactory.h"
#include "IDataBase.h"
class Server
{
public:
	void run();
protected:
	IDataBase* m_database;
	RequestHandleFactory m_handlerFactory_;

};