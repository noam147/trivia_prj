
#include "JsonResponsePacketSerializer.h"
#include <iostream>
#include <string>
#define _CRT_SECURE_NO_WARNINGS
char* JsonResponsePacketSerializer::serializeResponse(ErrorResponse error)
{
    std::string msg = "{\"message\":\""+error.message+"\"}";
    //json j = json::parse(R"({"message":"ERROR"})");
    json j = json::parse(msg);
    std::string jsonString = j.dump();//json to string
    std::string updateMsg = addLengthToMsg(jsonString);//add length to msg
    char codeMsg = ERROR_RESPONSE;
    updateMsg = codeMsg + updateMsg;//add codemsg

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());//copy
    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(LoginResponse log)
{

    std::string msg = "{\"status\":\"" + std::to_string(log.status) + "\"}";
    json j = json::parse(msg);

    std::string jsonString = j.dump();
    std::string updateMsg = addLengthToMsg(jsonString);
    char codeMsg = LOGIN_RESPONSE_SUCCESS;
    updateMsg = codeMsg + updateMsg;//add codemsg

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());

    return bytes;
}

char* JsonResponsePacketSerializer::serializeResponse(SignupResponse sign)
{
    std::string msg = "{\"status\":\"" + std::to_string(sign.status) + "\"}";
    json j = json::parse(msg);
    std::string jsonString = j.dump();
    std::string updateMsg = addLengthToMsg(jsonString);
    char codeMsg = SIGNUP_RESPONSE_SUCCESS;
    updateMsg = codeMsg + updateMsg;//add code

    char* bytes = new char[updateMsg.size() + 1];
    strcpy_s(bytes, updateMsg.size() + 1, updateMsg.c_str());
    return bytes;
}
std::string JsonResponsePacketSerializer::addLengthToMsg(std::string msg)
{
    unsigned int length = msg.length();
    char msgSize[sizeof(unsigned int) + 1] = { '\0' };
    memcpy(msgSize, &length, sizeof(unsigned int));
    return msgSize + msg;
}

