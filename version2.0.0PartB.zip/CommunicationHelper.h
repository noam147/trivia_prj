#pragma once

#include <vector>
#include <string>
#include <WinSock2.h>
#include "JsonResponsePacketSerializer.h"

enum MessageType : byte
{
	ERROR_RESPONSE = 40,
	LOGIN_RESPONSE_SUCCESS = 41,
	SIGNUP_RESPONSE_SUCCESS = 42,
	LOGOUT_RESPONSE = 4,
	GET_ROOM_RESPONSE = 5,
	GET_PLAYER_IN_ROOM_RESPONSE = 6,
	JOIN_ROOM_RESPONSE = 7,
	CREATE_ROOM_RESPONSE = 8,
	GET_HIGH_SCORE_RESPONSE = 9,
	GET_PERSONAL_STAT_RESPONSE = 10,
	CLOSE_ROOM_RESPONSE = 11,
	START_GAME_RESPONSE = 12,
	GET_ROOM_STATE_RESPONSE = 13,
	LEAVE_ROOM_RESPONSE = 14,
	GET_GAME_RESULT_RESPONSE = 15,
	SUBMIT_ANSWER_RESPONSE = 16,
	GET_QUESTION_RESPONSE = 17,
	LEAVE_GAME_RESPONSE = 18
};
enum clientMessageType : byte
{
	LOGIN_REQUEST = 71,
	SIGN_UP_REQUEST = 72,
	LOGOUT_REQUEST = 73,
	LOGIN_REQUEST_FAIL = 74,
	SIGN_UP_REQUEST_FAIL = 75
};
class CommunicationHelper
{
public:
	static int getMessageTypeCode(const SOCKET sc);
	static void sendHello(SOCKET sc);
	static int getIntPartFromSocket(const SOCKET sc, const int bytesNum);
	static int getLengthPartFromSocket(const SOCKET sc, const int bytesNum,char& codeMsg);
	static std::string getPartFromSocket(const SOCKET sc, const int bytesNum);
	static void sendData(const SOCKET sc, const std::string message);
	static std::string getPaddedNumber(const int num, const int digits);
	static char* stringToCharArr(std::string str);
	static char* createErrorResponse();


private:
	static std::string getPartFromSocket(const SOCKET sc, const int bytesNum, const int flags);

};

