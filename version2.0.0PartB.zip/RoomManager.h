#pragma once
#include <map>
#include "Room.h"
class RoomManager
{
public:
	void createRoom(LoggedUser user, RoomData roomdata);
	void deleteRoom(int ID);
	int getRoomState(int ID);
	std::vector<RoomData> getRooms();
	Room& getRoom(int ID);
private:
	std::map<int, Room> m_rooms;//roomID
	int _roomId = { 0 };
};