﻿using JsonSerialzierHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace clientGuiTrivia
{
    public partial class JoinRoomPage : Form
    {
        private string username;
        private string roomToJoin = "";
        private ClientHandler clientHandler;
        private List<Button> buttons = new List<Button>();
        public JoinRoomPage(string user, ClientHandler clientHandler)
        {
            this.username = user;
            this.clientHandler = clientHandler;
            
            InitializeComponent();
            this.label3.Text = this.username;
            this.joinButton.Enabled = false; //in the start the button is disabled 
            //send request to server to check avilable rooms
            refreshAction();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            loggedUserPage frm = new loggedUserPage(this.username, clientHandler);
            this.Close();
            frm.Show();
        }

        private void joinButton_Click(object sender, EventArgs e)
        {
            //send to sesrver request
            joinRoomMessageFields joinRoom = new joinRoomMessageFields();
            joinRoom.roomName = this.roomToJoin;
            string msgToSend = Serializer.serialize(joinRoom);
            clientHandler.sendMsg(msgToSend);
            string msgRecivied = clientHandler.receiveMsg();
            if(Deserializer.desirializeJoinRoomResponse(msgRecivied))
            {
                UserWaitingRoom frm = new UserWaitingRoom(this.username, roomToJoin, clientHandler);
                this.Close();
                frm.ShowDialog();
            }
           else
            {
                //display error label
            }

        }

        private void createButton(string roomName)
        {
            Button newButton = new Button();
            
            newButton.Text = roomName; ;
            newButton.Size = new System.Drawing.Size(100, 30);

            newButton.Click += (s, args) =>
            {
                Button clickedButton = s as Button;
                this.roomToJoin = clickedButton.Text;
                this.joinButton.Enabled=true;
            };

            // Add the button to the FlowLayoutPanel
            flowLayoutPanel1.Controls.Add(newButton);
            this.buttons.Add(newButton);
        }
        private void refreshAction()
        {
            getRoomsMessageFields getRooms = new getRoomsMessageFields();
            string msg = Serializer.serialize(getRooms);
            clientHandler.sendMsg(msg);
            string msgRecived = clientHandler.receiveMsg();
            List<string> roomNames = Deserializer.desirializeGetRoomsResponse(msgRecived);
            if (roomNames == null)
            {
                return;
            }

            this.RoomsList.Text = "RoomsList:\n";
            this.checkRoom.Text = "RoomsList:\n";
            this.RoomsList.Visible = true;
            foreach (Button b in this.buttons)
            {
                b.Dispose();//deleteing all the buttons
            }
            this.buttons = new List<Button>();
            for (int i = 0; i < roomNames.Count; i++)
            {

                string check = roomNames[i];
                createButton(roomNames[i]);
                this.checkRoom.Text += roomNames[i] + "\n";
                this.RoomsList.Text += roomNames[i] + "\n";
            }
        }
        private void refreshButton_Click(object sender, EventArgs e)
        {
            
            refreshAction();
        }
    }
}
