#include "MenuRequestHandler.h"

MenuRequestHandler::MenuRequestHandler(RequestHandleFactory& handlerFactory, LoggedUser user) :m_handlerFactory(handlerFactory),m_user(user)
{
}

bool MenuRequestHandler::isRequestRelevant(RequestInfo info)
{
    char msgType = info.buffer[0];
    if (msgType == LOGOUT_REQUEST || msgType == GET_ROOM_REQUEST || msgType == GET_PLAYER_IN_ROOM_REQUEST
        || msgType == GET_PERSONAL_STAT_REQUEST || msgType == GET_HIGH_SCORE_REQUEST || msgType == JOIN_ROOM_REQUEST
        || msgType == CREATE_ROOM_REQUEST)
        return true;

    return false;
}

RequestResult MenuRequestHandler::handleRequest(RequestInfo info)
{
	if (!isRequestRelevant(info))
	{
		RequestResult r;
		r.newHandler = nullptr;
		r.response = CommunicationHelper::createErrorResponse();
		return r;
	}
	char a = info.buffer[0];
	switch (info.buffer[0]) {
	case LOGOUT_REQUEST:
		return this->signout(info);
		break;
	case GET_ROOM_REQUEST:
		this->getRooms(info);
		break;
	case GET_PLAYER_IN_ROOM_REQUEST:
		this->getPlayersInRoom(info);
		break;
	case GET_PERSONAL_STAT_REQUEST:
		this->getPlayerStats(info);
		break;
	/*case GET_HIGH_SCORE_REQUEST:
		
		break;*/
	case JOIN_ROOM_REQUEST:
		this->joinRoom(info);
		break;
	case CREATE_ROOM_REQUEST:
		this->createRoom(info);
		break;
	default:
		throw RequestError();
	}
	
}

RequestResult MenuRequestHandler::signout(RequestInfo info)
{
    RequestResult r;
    r.newHandler = new LoginRequestHandler(this->m_handlerFactory);
    LogoutResponse l;
    l.status = 1;
    r.response = JsonResponsePacketSerializer::serializeResponse(l);
	this->m_handlerFactory.getLoginManager().logOut(m_user.getUserName());//log out from the active users
    return r;
}

RequestResult MenuRequestHandler::getRooms(RequestInfo info)
{
    RequestResult r;
    r.newHandler = new MenuRequestHandler(this->m_handlerFactory, this->m_user.getUserName());
    GetRoomResponse gr;
    gr.roomList = this->m_handlerFactory.getRoomManager().getRooms();
    r.response = JsonResponsePacketSerializer::serializeResponse(gr);
    return r;
}

RequestResult MenuRequestHandler::getPlayersInRoom(RequestInfo info)
{
	RequestResult r;
	GetPlayersRequest gprRequest;
	std::string str = "";

	for (int i = 0; i < info.buffer.size(); i++)
	{
		str += info.buffer[i];
	}
	try
	{
		gprRequest = JsonRequestPacketDeserializer::deserializeGetPlayersRequest(CommunicationHelper::stringToCharArr(str));
	}
	catch (const RequestError& e)
	{
		r.newHandler = nullptr;
		r.response = CommunicationHelper::createErrorResponse();
		return r;
	}
	catch (...)
	{
		r.newHandler = nullptr;
		r.response = CommunicationHelper::createErrorResponse();
		return r;
	}

	r.newHandler = new MenuRequestHandler(this->m_handlerFactory, this->m_user.getUserName());
	GetPlayersInRoomResponse gprResponse;
	gprResponse.userNames = this->m_handlerFactory.getRoomManager().getRoom(gprRequest.roomId).getAllUsers();
	r.response = JsonResponsePacketSerializer::serializeResponse(gprResponse);
	return r;
}

RequestResult MenuRequestHandler::joinRoom(RequestInfo info)
{
	RequestResult r;
	JoinRoomRequest jrRequest;
	std::string str = "";

	for (int i = 0; i < info.buffer.size(); i++)
	{
		str += info.buffer[i];
	}
	try
	{
		jrRequest = JsonRequestPacketDeserializer::deserializeJoinRoomRequest(CommunicationHelper::stringToCharArr(str));
	}
	catch (const RequestError& e)
	{
		r.newHandler = nullptr;
		r.response = CommunicationHelper::createErrorResponse();
		return r;
	}
	catch (...)
	{
		r.newHandler = nullptr;
		r.response = CommunicationHelper::createErrorResponse();
		return r;
	}
	this->m_handlerFactory.getRoomManager().getRoom(jrRequest.roomId).addUser(this->m_user);
	r.newHandler = new MenuRequestHandler(this->m_handlerFactory, this->m_user.getUserName());
	JoinRoomResponse jrResponse;
	jrResponse.status = 1;
	r.response = JsonResponsePacketSerializer::serializeResponse(jrResponse);
	return r;
}

RequestResult MenuRequestHandler::createRoom(RequestInfo info)
{
	RequestResult r;
	CreateRoomRequest crRequest;
	std::string str = "";

	for (int i = 0; i < info.buffer.size(); i++)
	{
		str += info.buffer[i];
	}
	try
	{
		crRequest = JsonRequestPacketDeserializer::deserializeCreateRoomRequest(CommunicationHelper::stringToCharArr(str));
	}
	catch (const RequestError& e)
	{
		r.newHandler = nullptr;
		r.response = CommunicationHelper::createErrorResponse();
		return r;
	}
	catch (...)
	{
		r.newHandler = nullptr;
		r.response = CommunicationHelper::createErrorResponse();
		return r;
	}
	
	unsigned int id = 1;
	if (!(this->m_handlerFactory.getRoomManager().getRooms().empty())) {
		id = this->m_handlerFactory.getRoomManager().getRooms().back().id;
	}

	RoomData rd = { id, crRequest.roomName, crRequest.maxUsers, crRequest.questionCount, crRequest.questionTimeout, 1 };
	this->m_handlerFactory.getRoomManager().createRoom(this->m_user, rd);
	r.newHandler = new MenuRequestHandler(this->m_handlerFactory, this->m_user.getUserName());
	JoinRoomResponse jrResponse;
	jrResponse.status = 1;
	r.response = JsonResponsePacketSerializer::serializeResponse(jrResponse);
	return r;
}

RequestResult MenuRequestHandler::getPlayerStats(RequestInfo info)
{
	RequestResult r;
	GetHighScoreResponse hsResponse = {this->m_handlerFactory.getStatisticsManager().getUserStatistics(this->m_user.getUserName())
		, this->m_handlerFactory.getStatisticsManager().getHighScore()};

	r.newHandler = new MenuRequestHandler(this->m_handlerFactory, this->m_user.getUserName());
	r.response = JsonResponsePacketSerializer::serializeResponse(hsResponse);
	return r;
}