#include "LoggedUser.h"

LoggedUser::LoggedUser(std::string username)
{
	_userName = username;
}

std::string LoggedUser::getUserName()
{
	return _userName;
}
