
#pragma once
#include <string>
#include "RoomManager.h"
#include "json.hpp"
#include "RequestError.hpp"
#include "CommunicationHelper.h"
using json = nlohmann::json;

struct ErrorResponse {
	std::string message;
};
struct LoginResponse {
	int status;
};
struct SignupResponse {
	int status;
};
typedef struct{
	int status;
} LogoutResponse;

typedef struct {
	int status;
} JoinRoomResponse;

typedef struct {
	int status;
} CreateRoomResponse;

typedef struct {
	std::vector<RoomData> roomList;
} GetRoomResponse;

typedef struct {
	std::vector<std::string> userNames;
} GetPlayersInRoomResponse;

typedef struct {
	std::vector<std::string> playerStatistics;
}GetPlayerStatisticsResponse;

typedef struct {
	std::vector<std::string> highScore;
} GetHighScoreResponse;

class JsonResponsePacketSerializer//msgs from the server to client
{
public:
	static char* serializeResponse(ErrorResponse error); //: Buffer
	static  char* serializeResponse(LoginResponse log); //: Buffer
	static  char* serializeResponse(SignupResponse sign); //: Buffer
	static  char* serializeResponse(LogoutResponse sign); //: Buffer
	static  char* serializeResponse(JoinRoomResponse sign); //: Buffer
	static  char* serializeResponse(CreateRoomResponse sign); //: Buffer
	static  char* serializeResponse(GetRoomResponse sign); //: Buffer
	static  char* serializeResponse(GetPlayersInRoomResponse sign); //: Buffer
	static  char* serializeResponse(GetHighScoreResponse sign); //: Buffer
	static  char* serializeResponse(GetPlayerStatisticsResponse sign); //: Buffer



	static std::string addLengthToMsg(std::string msg);//function will take regular msg and insert zeros to gete the protocol correctly, example: input: msg = "hello" output: "0005hello"
private:
	
};

